"""
annotate_pdf.py — Inference Engine + PDF Annotation Writer
Runs the trained layout model on new PDFs and writes feedback
directly onto the PDF as annotations, highlights, and summary pages.

Usage:
  python annotate_pdf.py \
      --input inspection_report.pdf \
      --checkpoint checkpoints/layout_best.pt \
      --tokenizer tokenizer/layout_bpe.model \
      --task issues \
      --output annotated_report.pdf
"""

import os
import re
import json
import logging
import argparse
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

import torch

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

try:
    import fitz
    HAS_FITZ = True
except ImportError:
    HAS_FITZ = False
    log.warning("PyMuPDF not found. Install: pip install pymupdf --break-system-packages")

try:
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.colors import red, orange, blue, green, black, HexColor
    HAS_REPORTLAB = True
except ImportError:
    HAS_REPORTLAB = False
    log.warning("ReportLab not found. Install: pip install reportlab --break-system-packages")

from pdf_parser import parse_pdf, ParsedDocument
from layout_tokenizer import LayoutBPETokenizer, PDFLayoutTokenizer
from layout_model import LayoutLM, LAYOUT_CONFIGS


# ──────────────────────────────────────────────
# Feedback parser
# ──────────────────────────────────────────────

@dataclass
class Finding:
    severity: str      # "critical", "warning", "info", "ok"
    element: str       # "Deck", "Superstructure", etc.
    description: str
    page: int
    location: Optional[Tuple[float, float, float, float]] = None  # x0,y0,x1,y1


def parse_model_output(output_text: str) -> List[Finding]:
    """
    Parse the model's text output into structured findings.
    The model is prompted to output findings in a consistent format.
    """
    findings = []
    lines = output_text.strip().split("\n")

    # Keywords that indicate severity
    critical_kw = ["critical", "imminent", "failure", "immediate", "unsafe", "emergency", "serious"]
    warning_kw  = ["warning", "poor", "deteriorat", "deficien", "repair", "monitor", "concern"]
    ok_kw       = ["good", "satisfactory", "excellent", "no issues", "no deficiencies"]

    # TxDOT element names to look for
    elements = [
        "Deck", "Superstructure", "Substructure", "Culvert",
        "Channel", "Bearing", "Joint", "Railing", "Approach",
        "Pier", "Abutment", "Foundation", "Scour"
    ]

    current_element = "General"
    current_page = 0

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Detect element
        for elem in elements:
            if elem.lower() in line.lower():
                current_element = elem
                break

        # Detect severity
        line_lower = line.lower()
        if any(k in line_lower for k in critical_kw):
            severity = "critical"
        elif any(k in line_lower for k in warning_kw):
            severity = "warning"
        elif any(k in line_lower for k in ok_kw):
            severity = "ok"
        else:
            severity = "info"

        if len(line) > 15:  # skip very short lines
            findings.append(Finding(
                severity=severity,
                element=current_element,
                description=line,
                page=current_page
            ))

    return findings


# ──────────────────────────────────────────────
# PDF Annotation Writer
# ──────────────────────────────────────────────

SEVERITY_COLORS = {
    "critical": (1.0, 0.2, 0.2),   # red
    "warning":  (1.0, 0.6, 0.0),   # orange
    "info":     (0.1, 0.4, 0.8),   # blue
    "ok":       (0.2, 0.6, 0.1),   # green
}

SEVERITY_LABELS = {
    "critical": "⚠ CRITICAL",
    "warning":  "⚡ WARNING",
    "info":     "ℹ INFO",
    "ok":       "✓ OK",
}


def add_annotations_to_pdf(
    source_pdf: str,
    findings: List[Finding],
    output_pdf: str,
    model_output: str,
    task: str
):
    """
    Add AI findings as annotations to the original PDF.
    Creates:
    1. Sticky note annotations on relevant pages
    2. A summary page appended at the end
    """
    if not HAS_FITZ:
        raise ImportError("PyMuPDF required: pip install pymupdf --break-system-packages")

    doc = fitz.open(source_pdf)

    # Add sticky note annotations to pages
    # Group findings by page
    by_page: Dict[int, List[Finding]] = {}
    for f in findings:
        by_page.setdefault(f.page, []).append(f)

    for page_num, page_findings in by_page.items():
        if page_num >= doc.page_count:
            page_num = 0  # default to first page if page unknown
        page = doc[page_num]
        page_rect = page.rect

        # Add findings as sticky notes staggered down the right margin
        y_offset = 50
        for finding in page_findings:
            color = SEVERITY_COLORS.get(finding.severity, (0.5, 0.5, 0.5))
            label = SEVERITY_LABELS.get(finding.severity, "ℹ")

            # Annotation position: right margin
            note_rect = fitz.Rect(
                page_rect.width - 30,
                y_offset,
                page_rect.width - 10,
                y_offset + 20
            )

            # Add sticky note annotation
            annot = page.add_text_annot(
                point=fitz.Point(page_rect.width - 25, y_offset + 10),
                text=f"{label}: {finding.element}\n\n{finding.description}",
                icon="Note"
            )
            annot.set_colors(stroke=color, fill=color)
            annot.set_info(title="TxDOT AI Inspector", subject=finding.severity.upper())
            annot.update()

            # If we know the location, add a highlight box
            if finding.location:
                x0, y0, x1, y1 = finding.location
                highlight_rect = fitz.Rect(x0, y0, x1, y1)
                hl = page.add_rect_annot(highlight_rect)
                hl.set_colors(stroke=color)
                hl.set_border(width=2)
                hl.update()

            y_offset += 30
            if y_offset > page_rect.height - 50:
                y_offset = 50

    # Add summary page at the end
    summary_page = doc.new_page(width=612, height=792)

    # Title
    summary_page.insert_text(
        fitz.Point(50, 60),
        "TxDOT AI Inspection Analysis Report",
        fontsize=18, color=(0.1, 0.3, 0.6), fontname="helv"
    )
    summary_page.insert_text(
        fitz.Point(50, 82),
        f"Source: {Path(source_pdf).name}   |   Task: {task.upper()}",
        fontsize=10, color=(0.4, 0.4, 0.4), fontname="helv"
    )

    # Divider line
    summary_page.draw_line(fitz.Point(50, 90), fitz.Point(562, 90), color=(0.8,0.8,0.8), width=1)

    # Count findings by severity
    counts = {"critical": 0, "warning": 0, "info": 0, "ok": 0}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    # Summary stats
    y = 110
    summary_page.insert_text(fitz.Point(50, y), "Summary", fontsize=13,
                               color=(0.1,0.1,0.1), fontname="helv")
    y += 20
    for sev, count in counts.items():
        color = SEVERITY_COLORS.get(sev, (0,0,0))
        label = SEVERITY_LABELS.get(sev, sev)
        summary_page.insert_text(
            fitz.Point(60, y),
            f"{label}: {count} finding(s)",
            fontsize=11, color=color, fontname="helv"
        )
        y += 18

    y += 15
    summary_page.draw_line(fitz.Point(50, y), fitz.Point(562, y), color=(0.8,0.8,0.8), width=0.5)
    y += 15

    # Full model output
    summary_page.insert_text(fitz.Point(50, y), "Detailed Findings", fontsize=13,
                               color=(0.1,0.1,0.1), fontname="helv")
    y += 20

    # Word-wrap the model output onto the page
    words = model_output.split()
    line_buf = []
    max_chars = 90

    for word in words:
        line_buf.append(word)
        if len(" ".join(line_buf)) > max_chars:
            line_text = " ".join(line_buf[:-1])
            if y > 750:  # new page
                summary_page = doc.new_page(width=612, height=792)
                y = 50
            summary_page.insert_text(
                fitz.Point(50, y), line_text,
                fontsize=9, color=(0.1,0.1,0.1), fontname="helv"
            )
            y += 14
            line_buf = [word]

    if line_buf:
        summary_page.insert_text(
            fitz.Point(50, y), " ".join(line_buf),
            fontsize=9, color=(0.1,0.1,0.1), fontname="helv"
        )

    doc.save(output_pdf, garbage=4, deflate=True)
    doc.close()
    log.info(f"Annotated PDF saved: {output_pdf}")


# ──────────────────────────────────────────────
# Inference Engine
# ──────────────────────────────────────────────

class LayoutInference:
    def __init__(self, checkpoint_path: str, tokenizer_path: str,
                 model_size: str = "small"):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        log.info(f"Loading model from {checkpoint_path}")

        self.tokenizer = LayoutBPETokenizer(tokenizer_path)

        cfg = LAYOUT_CONFIGS[model_size]
        cfg.vocab_size = self.tokenizer.vocab_size
        self.model = LayoutLM(cfg).to(self.device)

        ckpt = torch.load(checkpoint_path, map_location=self.device)
        self.model.load_state_dict(ckpt["model"])
        self.model.eval()
        log.info("Model loaded and ready")

    def analyze(self, pdf_path: str, task: str = "issues",
                max_pages: int = 5, max_new_tokens: int = 512) -> str:
        """
        Run inference on a PDF file. Returns model's text output.
        """
        from pdf_parser import parse_pdf
        log.info(f"Parsing PDF: {pdf_path}")
        parsed = parse_pdf(pdf_path)

        import json
        from dataclasses import asdict
        doc_dict = asdict(parsed)

        token_ids = self.tokenizer.encode_doc_for_inference(doc_dict, task, max_pages)
        token_tensor = torch.tensor([token_ids], dtype=torch.long).to(self.device)

        log.info(f"Generating analysis — {len(token_ids)} input tokens")
        with torch.no_grad():
            output = self.model.generate(
                token_tensor,
                max_new_tokens=max_new_tokens,
                temperature=0.3,
                top_k=40,
                stop_token=self.tokenizer.eos_id
            )

        # Decode only the new tokens
        new_tokens = output[0, len(token_ids):].tolist()
        result = self.tokenizer.decode(new_tokens)

        # Clean up layout tokens from output
        result = re.sub(r'\[/?[A-Z_0-9]+\]', '', result)
        result = re.sub(r'\s+', ' ', result).strip()
        return result


# ──────────────────────────────────────────────
# Simple labeling tool (creates training data)
# ──────────────────────────────────────────────

def run_labeling_tool(parsed_dir: str, output_dir: str):
    """
    Simple command-line labeling tool for creating SFT training examples.
    Walks through parsed PDFs and prompts the user to provide analysis responses.
    """
    parsed_dir = Path(parsed_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    jsons = sorted(parsed_dir.glob("*.json"))
    tasks = ["issues", "summary", "ratings", "missing", "recs"]

    print(f"\nLabeling tool — {len(jsons)} documents found")
    print("For each document, provide the correct analysis response.")
    print("Press Enter to skip, 'q' to quit.\n")

    for jpath in jsons:
        label_out = output_dir / (jpath.stem + "_label.json")
        if label_out.exists():
            print(f"Skipping (already labeled): {jpath.name}")
            continue

        print(f"\n{'='*60}")
        print(f"Document: {jpath.name}")

        with open(jpath, "r") as f:
            doc = json.load(f)

        # Show a preview of the document text
        preview_texts = []
        for page in doc.get("pages", [])[:2]:
            for block in page.get("blocks", [])[:10]:
                if block.get("text"):
                    preview_texts.append(block["text"])

        print("Preview:", " | ".join(preview_texts[:8]))

        print(f"\nTask options: {', '.join(tasks)}")
        task = input("Task (or Enter to skip, q to quit): ").strip().lower()

        if task == 'q':
            break
        if task not in tasks:
            print("Skipping.")
            continue

        print(f"Enter your analysis response for task '{task}'")
        print("(Type your response, then press Enter twice when done)")
        lines = []
        while True:
            line = input()
            if line == "":
                if lines and lines[-1] == "":
                    break
            lines.append(line)
        response = "\n".join(lines).strip()

        if response:
            label = {
                "pdf": jpath.name,
                "task": task,
                "response": response,
                "pages": None  # use all pages
            }
            with open(label_out, "w") as f:
                json.dump(label, f, indent=2)
            print(f"✓ Saved: {label_out.name}")
        else:
            print("Empty response — skipping.")

    print("\nLabeling session complete.")


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PDF annotation and labeling tool")
    sub = parser.add_subparsers(dest="cmd")

    # Annotate a PDF
    pa = sub.add_parser("annotate", help="Run model on PDF and produce annotated output")
    pa.add_argument("--input",      required=True, help="Input PDF path")
    pa.add_argument("--output",     required=True, help="Output annotated PDF path")
    pa.add_argument("--checkpoint", required=True, help="Model checkpoint .pt file")
    pa.add_argument("--tokenizer",  required=True, help="Tokenizer .model file")
    pa.add_argument("--task",       default="issues",
                    choices=["issues","summary","ratings","missing","recs","analyze"])
    pa.add_argument("--model-size", default="small", choices=["small","medium","large"])
    pa.add_argument("--max-pages",  type=int, default=5)
    pa.add_argument("--max-tokens", type=int, default=512)

    # Labeling tool
    pl = sub.add_parser("label", help="Run interactive labeling tool to create training data")
    pl.add_argument("--parsed-dir",  default="./data/processed")
    pl.add_argument("--output-dir",  default="./data/labeled")

    args = parser.parse_args()

    if args.cmd == "annotate":
        engine = LayoutInference(args.checkpoint, args.tokenizer, args.model_size)
        output_text = engine.analyze(args.input, args.task, args.max_pages, args.max_tokens)
        print("\n" + "="*60)
        print("MODEL OUTPUT:")
        print("="*60)
        print(output_text)
        print("="*60 + "\n")

        findings = parse_model_output(output_text)
        log.info(f"Parsed {len(findings)} findings")
        add_annotations_to_pdf(args.input, findings, args.output, output_text, args.task)
        print(f"Annotated PDF saved: {args.output}")

    elif args.cmd == "label":
        run_labeling_tool(args.parsed_dir, args.output_dir)

    else:
        parser.print_help()
