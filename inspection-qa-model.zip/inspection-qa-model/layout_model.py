"""
layout_model.py — Layout-Aware Transformer for PDF Understanding
Extends a standard decoder-only transformer with:
  - 2D spatial position encodings (x, y coordinates)
  - Block type embeddings (header, table, form field, etc.)
  - Font style embeddings (bold, italic, size)
  - Cross-page attention for multi-page documents
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Optional, Tuple


# ──────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────

@dataclass
class LayoutModelConfig:
    # Core transformer
    vocab_size:      int   = 18000   # BPE vocab + special tokens
    n_layers:        int   = 12
    n_heads:         int   = 12
    n_kv_heads:      int   = 4       # GQA
    d_model:         int   = 768
    d_ff:            int   = 3072
    max_seq_len:     int   = 4096    # longer context for multi-page docs
    dropout:         float = 0.1
    bias:            bool  = False
    tie_weights:     bool  = True

    # Layout-specific
    n_block_types:   int   = 16      # header, text, label, table, cell, field, etc.
    n_font_sizes:    int   = 4       # small, normal, large, title
    coord_bins:      int   = 10      # position grid (10x10)
    n_page_zones:    int   = 100     # coord_bins^2

    # RoPE
    rope_theta:      float = 10000.0

    def __post_init__(self):
        assert self.d_model % self.n_heads == 0
        assert self.n_heads % self.n_kv_heads == 0
        self.head_dim = self.d_model // self.n_heads


BLOCK_TYPE_MAP = {
    "text": 0, "header": 1, "label": 2, "numeric_field": 3,
    "table": 4, "table_cell": 5, "table_header": 6,
    "form_field": 7, "checkbox": 8, "separator": 9,
    "page_start": 10, "page_end": 11,
    "doc_start": 12, "doc_end": 13,
    "task": 14, "response": 15,
}


# ──────────────────────────────────────────────
# RMSNorm
# ──────────────────────────────────────────────

class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rms = x.float().pow(2).mean(-1, keepdim=True).add(self.eps).rsqrt()
        return (x.float() * rms).to(x.dtype) * self.weight


# ──────────────────────────────────────────────
# Rotary Position Embeddings
# ──────────────────────────────────────────────

def precompute_freqs_cis(head_dim: int, max_seq: int, theta: float = 10000.0):
    freqs = 1.0 / (theta ** (torch.arange(0, head_dim, 2).float() / head_dim))
    t = torch.arange(max_seq)
    freqs = torch.outer(t, freqs)
    return torch.polar(torch.ones_like(freqs), freqs)

def apply_rotary_emb(xq, xk, freqs_cis):
    def rot(x):
        x_ = x.float().reshape(*x.shape[:-1], -1, 2)
        xc = torch.view_as_complex(x_)
        return torch.view_as_real(xc * freqs_cis.unsqueeze(0).unsqueeze(2)).flatten(-2).type_as(x)
    return rot(xq), rot(xk)


# ──────────────────────────────────────────────
# 2D Spatial Embedding
# ──────────────────────────────────────────────

class SpatialEmbedding(nn.Module):
    """
    Encodes the 2D position of each token on the page.
    Each token gets an (x_zone, y_zone) embedding added to its content embedding.
    This lets the model know WHERE on the page each piece of text lives.
    """
    def __init__(self, cfg: LayoutModelConfig):
        super().__init__()
        self.x_emb = nn.Embedding(cfg.coord_bins, cfg.d_model // 4)
        self.y_emb = nn.Embedding(cfg.coord_bins, cfg.d_model // 4)
        self.proj  = nn.Linear(cfg.d_model // 2, cfg.d_model, bias=False)

    def forward(self, x_zones: torch.Tensor, y_zones: torch.Tensor) -> torch.Tensor:
        """
        x_zones: [B, T] integer zone ids (0-9)
        y_zones: [B, T] integer zone ids (0-9)
        Returns: [B, T, d_model] spatial embeddings
        """
        xe = self.x_emb(x_zones)
        ye = self.y_emb(y_zones)
        spatial = torch.cat([xe, ye], dim=-1)
        return self.proj(spatial)


# ──────────────────────────────────────────────
# Layout Embedding (block type + font style)
# ──────────────────────────────────────────────

class LayoutEmbedding(nn.Module):
    """
    Encodes structural metadata about each token:
    - Block type (header, table, form field, etc.)
    - Font size category
    - Bold / italic flags
    """
    def __init__(self, cfg: LayoutModelConfig):
        super().__init__()
        self.block_type_emb = nn.Embedding(cfg.n_block_types, cfg.d_model // 2)
        self.font_size_emb  = nn.Embedding(cfg.n_font_sizes,  cfg.d_model // 4)
        self.style_emb      = nn.Embedding(4, cfg.d_model // 4)  # none, bold, italic, both
        self.proj = nn.Linear(cfg.d_model, cfg.d_model, bias=False)

    def forward(self, block_types: torch.Tensor, font_sizes: torch.Tensor,
                styles: torch.Tensor) -> torch.Tensor:
        bt = self.block_type_emb(block_types)
        fs = self.font_size_emb(font_sizes)
        st = self.style_emb(styles)
        layout = torch.cat([bt, fs, st], dim=-1)
        return self.proj(layout)


# ──────────────────────────────────────────────
# Grouped Query Attention
# ──────────────────────────────────────────────

class GQAttention(nn.Module):
    def __init__(self, cfg: LayoutModelConfig):
        super().__init__()
        self.n_heads    = cfg.n_heads
        self.n_kv_heads = cfg.n_kv_heads
        self.head_dim   = cfg.head_dim
        self.n_rep      = cfg.n_heads // cfg.n_kv_heads

        self.wq = nn.Linear(cfg.d_model, cfg.n_heads    * cfg.head_dim, bias=cfg.bias)
        self.wk = nn.Linear(cfg.d_model, cfg.n_kv_heads * cfg.head_dim, bias=cfg.bias)
        self.wv = nn.Linear(cfg.d_model, cfg.n_kv_heads * cfg.head_dim, bias=cfg.bias)
        self.wo = nn.Linear(cfg.n_heads * cfg.head_dim, cfg.d_model,    bias=cfg.bias)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x: torch.Tensor, freqs_cis: torch.Tensor,
                mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        B, T, _ = x.shape
        q = self.wq(x).view(B, T, self.n_heads,    self.head_dim)
        k = self.wk(x).view(B, T, self.n_kv_heads, self.head_dim)
        v = self.wv(x).view(B, T, self.n_kv_heads, self.head_dim)

        q, k = apply_rotary_emb(q, k, freqs_cis[:T])

        if self.n_rep > 1:
            k = k.unsqueeze(3).expand(B, T, self.n_kv_heads, self.n_rep, self.head_dim).reshape(B, T, self.n_heads, self.head_dim)
            v = v.unsqueeze(3).expand(B, T, self.n_kv_heads, self.n_rep, self.head_dim).reshape(B, T, self.n_heads, self.head_dim)

        q, k, v = q.transpose(1,2), k.transpose(1,2), v.transpose(1,2)
        out = F.scaled_dot_product_attention(q, k, v, attn_mask=mask,
                                              dropout_p=self.drop.p if self.training else 0.0,
                                              is_causal=(mask is None))
        return self.wo(out.transpose(1,2).contiguous().view(B, T, -1))


# ──────────────────────────────────────────────
# SwiGLU FFN
# ──────────────────────────────────────────────

class SwiGLU(nn.Module):
    def __init__(self, cfg: LayoutModelConfig):
        super().__init__()
        hidden = 256 * ((int(2/3 * cfg.d_ff) + 255) // 256)
        self.w1 = nn.Linear(cfg.d_model, hidden, bias=cfg.bias)
        self.w2 = nn.Linear(hidden, cfg.d_model, bias=cfg.bias)
        self.w3 = nn.Linear(cfg.d_model, hidden, bias=cfg.bias)
        self.drop = nn.Dropout(cfg.dropout)

    def forward(self, x):
        return self.drop(self.w2(F.silu(self.w1(x)) * self.w3(x)))


# ──────────────────────────────────────────────
# Transformer Block
# ──────────────────────────────────────────────

class TransformerBlock(nn.Module):
    def __init__(self, cfg: LayoutModelConfig):
        super().__init__()
        self.norm1 = RMSNorm(cfg.d_model)
        self.attn  = GQAttention(cfg)
        self.norm2 = RMSNorm(cfg.d_model)
        self.ff    = SwiGLU(cfg)
        self.drop  = nn.Dropout(cfg.dropout)

    def forward(self, x, freqs_cis, mask=None):
        x = x + self.drop(self.attn(self.norm1(x), freqs_cis, mask))
        x = x + self.drop(self.ff(self.norm2(x)))
        return x


# ──────────────────────────────────────────────
# Full Layout Language Model
# ──────────────────────────────────────────────

class LayoutLM(nn.Module):
    """
    Layout-aware language model for PDF document understanding.

    Input per token:
      - token_ids:    vocabulary token
      - x_zones:      horizontal position zone (0-9)
      - y_zones:      vertical position zone (0-9)
      - block_types:  semantic block type
      - font_sizes:   font size category
      - styles:       bold/italic flags

    The model fuses all of these into a unified representation,
    then autoregressively generates feedback/analysis text.
    """
    def __init__(self, cfg: LayoutModelConfig):
        super().__init__()
        self.cfg = cfg

        # Core embeddings
        self.tok_emb     = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.spatial_emb = SpatialEmbedding(cfg)
        self.layout_emb  = LayoutEmbedding(cfg)
        self.emb_norm    = RMSNorm(cfg.d_model)
        self.drop        = nn.Dropout(cfg.dropout)

        # Transformer blocks
        self.blocks  = nn.ModuleList([TransformerBlock(cfg) for _ in range(cfg.n_layers)])
        self.norm_f  = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)

        if cfg.tie_weights:
            self.lm_head.weight = self.tok_emb.weight

        # RoPE frequencies
        freqs = precompute_freqs_cis(cfg.head_dim, cfg.max_seq_len, cfg.rope_theta)
        self.register_buffer("freqs_cis", freqs, persistent=False)

        self.apply(self._init_weights)
        scale = (2 * cfg.n_layers) ** -0.5
        for name, p in self.named_parameters():
            if name.endswith(("wo.weight", "w2.weight")):
                nn.init.normal_(p, mean=0.0, std=0.02 * scale)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, 0.0, 0.02)
            if m.bias is not None: nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, 0.0, 0.02)

    def forward(self,
                token_ids:   torch.Tensor,
                x_zones:     Optional[torch.Tensor] = None,
                y_zones:     Optional[torch.Tensor] = None,
                block_types: Optional[torch.Tensor] = None,
                font_sizes:  Optional[torch.Tensor] = None,
                styles:      Optional[torch.Tensor] = None,
                targets:     Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        B, T = token_ids.shape
        assert T <= self.cfg.max_seq_len

        # Token embedding
        x = self.tok_emb(token_ids)

        # Add spatial embedding if provided
        if x_zones is not None and y_zones is not None:
            x = x + self.spatial_emb(x_zones, y_zones)

        # Add layout embedding if provided
        if block_types is not None:
            # Default font_sizes and styles if not provided
            if font_sizes is None:
                font_sizes = torch.ones_like(block_types)
            if styles is None:
                styles = torch.zeros_like(block_types)
            x = x + self.layout_emb(block_types, font_sizes, styles)

        x = self.drop(self.emb_norm(x))
        freqs = self.freqs_cis[:T]

        for block in self.blocks:
            x = block(x, freqs)

        x = self.norm_f(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            loss = F.cross_entropy(
                logits.view(-1, self.cfg.vocab_size),
                targets.view(-1),
                ignore_index=-100
            )

        return logits, loss

    @torch.no_grad()
    def generate(self, token_ids: torch.Tensor,
                 x_zones=None, y_zones=None,
                 block_types=None, font_sizes=None, styles=None,
                 max_new_tokens: int = 512,
                 temperature: float = 0.3,
                 top_k: int = 40,
                 top_p: float = 0.9,
                 repetition_penalty: float = 1.3,
                 no_repeat_ngram_size: int = 4,
                 stop_token: int = 3) -> torch.Tensor:
        """Autoregressive generation with repetition penalty and n-gram blocking."""
        B = token_ids.shape[0]
        prompt_len = token_ids.shape[1]

        for _ in range(max_new_tokens):
            idx_cond = token_ids[:, -self.cfg.max_seq_len:]
            T = idx_cond.shape[1]
            xz = x_zones[:, -T:] if x_zones is not None else None
            yz = y_zones[:, -T:] if y_zones is not None else None
            bt = block_types[:, -T:] if block_types is not None else None
            fs = font_sizes[:, -T:] if font_sizes is not None else None
            st = styles[:, -T:] if styles is not None else None

            logits, _ = self(idx_cond, xz, yz, bt, fs, st)
            logits = logits[:, -1, :] / temperature

            # Repetition penalty + no-repeat-ngram blocking, per batch item
            for b in range(B):
                generated = token_ids[b].tolist()

                # Repetition penalty: push down logits of tokens already used
                if repetition_penalty != 1.0:
                    for tok in set(generated):
                        if logits[b, tok] < 0:
                            logits[b, tok] *= repetition_penalty
                        else:
                            logits[b, tok] /= repetition_penalty

                # No-repeat-ngram: ban tokens that would recreate a seen n-gram
                if no_repeat_ngram_size > 0 and len(generated) >= no_repeat_ngram_size - 1:
                    n = no_repeat_ngram_size
                    prefix = tuple(generated[-(n - 1):])
                    for i in range(len(generated) - n + 1):
                        if tuple(generated[i:i + n - 1]) == prefix:
                            banned_tok = generated[i + n - 1]
                            logits[b, banned_tok] = float('-inf')

            if top_k > 0:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, -1:]] = float('-inf')

            if top_p < 1.0:
                sorted_logits, sorted_idx = torch.sort(logits, descending=True)
                cum_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
                remove = cum_probs - F.softmax(sorted_logits, dim=-1) > top_p
                sorted_logits[remove] = float('-inf')
                logits = torch.zeros_like(logits).scatter_(1, sorted_idx, sorted_logits)

            probs = F.softmax(logits, dim=-1)
            next_tok = torch.multinomial(probs, 1)
            token_ids = torch.cat([token_ids, next_tok], dim=1)

            if next_tok.item() == stop_token:
                break

        return token_ids

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


# ──────────────────────────────────────────────
# Preset configs
# ──────────────────────────────────────────────

LAYOUT_CONFIGS = {
    "small":  LayoutModelConfig(n_layers=12, n_heads=12, n_kv_heads=4,  d_model=768,  d_ff=3072, max_seq_len=4096),
    "medium": LayoutModelConfig(n_layers=24, n_heads=16, n_kv_heads=8,  d_model=1024, d_ff=4096, max_seq_len=4096),
    "large":  LayoutModelConfig(n_layers=32, n_heads=32, n_kv_heads=8,  d_model=2048, d_ff=8192, max_seq_len=8192),
}

if __name__ == "__main__":
    cfg = LAYOUT_CONFIGS["small"]
    model = LayoutLM(cfg)
    print(f"Parameters: {model.count_parameters():,}")

    B, T = 2, 128
    ids   = torch.randint(0, cfg.vocab_size, (B, T))
    xz    = torch.randint(0, cfg.coord_bins, (B, T))
    yz    = torch.randint(0, cfg.coord_bins, (B, T))
    bt    = torch.randint(0, cfg.n_block_types, (B, T))
    fs    = torch.randint(0, cfg.n_font_sizes,  (B, T))
    st    = torch.randint(0, 4, (B, T))

    logits, loss = model(ids, xz, yz, bt, fs, st, targets=ids)
    print(f"Forward pass OK — logits: {logits.shape}, loss: {loss.item():.4f}")
