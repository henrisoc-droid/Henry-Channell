"""
pair_builder.py — Field Notes to Final Report Pair Builder
Matches by bridge folder name. Each bridge has its own folder.

data/raw_pdfs/
  field_notes/
    00-000-0000-00-001/   <- folder name IS the structure ID
      2024_Field_Notes.pdf
      2025_Field_Notes.pdf
  final_product/
    00-000-0000-00-001/
      2024_RTInsp_Final.pdf
      2025_RTInsp_Final.pdf

Usage:
  python pair_builder.py match   -- auto-match by folder name
  python pair_builder.py show    -- review pairs
  python pair_builder.py manual  -- fix unmatched files
  python pair_builder.py build   -- build SFT training corpus
"""

import os
import re
import json
import logging
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


@dataclass
class DocumentPair:
    pair_id:           str
    structure_id:      str
    field_notes_pdf:   str
    final_report_pdf:  str
    field_notes_json:  str
    final_report_json: str
    matched_by:        str
    confidence:        float
    year:              str


YEAR_RE = re.compile(r'(20\d{2})')

def extract_year(text: str) -> str:
    m = YEAR_RE.search(text)
    return m.group(1) if m else ""


def _make_pair(sid, fn_pdf, fp_pdf, fn_json_root, fp_json_root,
               matched_by, confidence, year=""):
    fn_json = fn_json_root / fn_pdf.parent.name / (fn_pdf.stem + ".json")
    fp_json = fp_json_root / fp_pdf.parent.name / (fp_pdf.stem + ".json")
    pair_id = f"{sid}_{year or 'noyear'}_{matched_by}"
    return DocumentPair(
        pair_id=pair_id,
        structure_id=sid,
        field_notes_pdf=str(fn_pdf),
        final_report_pdf=str(fp_pdf),
        field_notes_json=str(fn_json),
        final_report_json=str(fp_json),
        matched_by=matched_by,
        confidence=confidence,
        year=year or extract_year(fn_pdf.name)
    )


def _group_by_year(pdfs):
    by_year = {}
    for pdf in pdfs:
        y = extract_year(pdf.name) or extract_year(str(pdf.parent)) or "unknown"
        by_year.setdefault(y, []).append(pdf)
    return by_year


def match_by_folder(fn_dir, fp_dir, fn_json_dir, fp_json_dir):
    fn_root  = Path(fn_dir)
    fp_root  = Path(fp_dir)
    fn_json  = Path(fn_json_dir)
    fp_json  = Path(fp_json_dir)

    fn_folders = {d.name: d for d in fn_root.iterdir() if d.is_dir() and not d.name.startswith('.')}
    fp_folders = {d.name: d for d in fp_root.iterdir() if d.is_dir() and not d.name.startswith('.')}

    log.info(f"Field note bridge folders:    {len(fn_folders)}")
    log.info(f"Final product bridge folders: {len(fp_folders)}")

    pairs = []
    unmatched = []

    for bridge_id in sorted(set(fn_folders) | set(fp_folders)):
        fn_folder = fn_folders.get(bridge_id)
        fp_folder = fp_folders.get(bridge_id)

        if not fn_folder:
            log.warning(f"No field notes folder for: {bridge_id}")
            unmatched.append(bridge_id)
            continue
        if not fp_folder:
            log.warning(f"No final product folder for: {bridge_id}")
            unmatched.append(bridge_id)
            continue

        fn_pdfs = sorted(fn_folder.glob("*.pdf"))
        fp_pdfs = sorted(fp_folder.glob("*.pdf"))

        if not fn_pdfs or not fp_pdfs:
            log.warning(f"Empty folder for bridge: {bridge_id}")
            continue

        # ── Priority match: "Combined Field Notes" <-> RTInsp / SNBI ──
        # These are the canonical source/output file pairs. When present,
        # they take precedence over any other file in the folder (photo
        # logs, review copies, closure docs, etc.) so we don't accidentally
        # pair the wrong document just because it happened to be "latest."
        fn_combined = [p for p in fn_pdfs if "combined field notes" in p.name.lower()]
        fp_rtinsp   = [p for p in fp_pdfs if "rtinsp" in p.name.lower()]
        fp_snbi     = [p for p in fp_pdfs if "snbi" in p.name.lower()]
        fp_priority = fp_rtinsp + fp_snbi  # RTInsp preferred, SNBI included too

        if fn_combined and fp_priority:
            if len(fn_combined) > 1:
                log.warning(f"[{bridge_id}] {len(fn_combined)} 'Combined Field Notes' "
                            f"files found — using {fn_combined[0].name}")
            fn_pdf = fn_combined[0]
            for fp_pdf in fp_priority:
                kind = "rtinsp" if fp_pdf in fp_rtinsp else "snbi"
                pairs.append(_make_pair(bridge_id, fn_pdf, fp_pdf,
                                        fn_json, fp_json,
                                        f"name_priority_{kind}", 1.0))
                log.info(f"✓✓ [{bridge_id}] {fn_pdf.name} <-> {fp_pdf.name} (priority: {kind})")
            continue

        # Single PDF each side — direct match
        if len(fn_pdfs) == 1 and len(fp_pdfs) == 1:
            pairs.append(_make_pair(bridge_id, fn_pdfs[0], fp_pdfs[0],
                                    fn_json, fp_json, "folder_direct", 1.0))
            log.info(f"✓ [{bridge_id}] {fn_pdfs[0].name} <-> {fp_pdfs[0].name}")
            continue

        # Multiple PDFs — match by year
        fn_by_year = _group_by_year(fn_pdfs)
        fp_by_year = _group_by_year(fp_pdfs)
        matched_years = set()

        for year in sorted(set(fn_by_year) & set(fp_by_year)):
            for fn_pdf in fn_by_year[year]:
                for fp_pdf in fp_by_year[year]:
                    pairs.append(_make_pair(bridge_id, fn_pdf, fp_pdf,
                                            fn_json, fp_json, "folder_year", 0.95, year))
                    log.info(f"✓ [{bridge_id}][{year}] {fn_pdf.name} <-> {fp_pdf.name}")
            matched_years.add(year)

        # Remaining unmatched years — pair by order
        fn_rem = [p for y, ps in fn_by_year.items() if y not in matched_years for p in ps]
        fp_rem = [p for y, ps in fp_by_year.items() if y not in matched_years for p in ps]

        if fn_rem and fp_rem:
            fp_latest = sorted(fp_rem)[-1]
            for fn_pdf in fn_rem:
                pairs.append(_make_pair(bridge_id, fn_pdf, fp_latest,
                                        fn_json, fp_json, "folder_latest", 0.75))
                log.info(f"~ [{bridge_id}] {fn_pdf.name} <-> {fp_latest.name} (latest)")

    log.info(f"\nMatched: {len(pairs)} pairs | Unmatched bridges: {len(unmatched)}")
    if unmatched:
        for b in unmatched:
            log.info(f"  missing folder: {b}")

    return pairs


def extract_text_from_json(json_path, max_pages=5):
    if not json_path or not Path(json_path).exists():
        return ""
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            doc = json.load(f)
        parts = []
        for page in doc.get("pages", [])[:max_pages]:
            pt = f"[Page {page['page_num']+1}]\n"
            for block in sorted(page.get("blocks", []), key=lambda b: b.get("reading_order", 0))[:60]:
                text = block.get("text", "").strip()
                if text:
                    prefix = "## " if block.get("block_type") == "header" else \
                             "FIELD: " if block.get("block_type") == "label" else ""
                    pt += prefix + text + "\n"
            for table in page.get("tables", []):
                pt += "\nTABLE:\n"
                rows = {}
                for cell in table.get("cells", []):
                    rows.setdefault(cell["row"], []).append(cell.get("text", ""))
                for r in sorted(rows.keys())[:10]:
                    pt += " | ".join(rows[r]) + "\n"
            for field in page.get("form_fields", []):
                if field.get("field_name"):
                    pt += f"[{field['field_name']}]: {field.get('field_value','')}\n"
            parts.append(pt)
        return "\n".join(parts)
    except Exception as e:
        log.warning(f"Could not read {json_path}: {e}")
        return ""


def build_sft_corpus_from_pairs(pairs, output_file, min_confidence=0.7):
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    examples, skipped = [], 0

    for pair in pairs:
        if pair.confidence < min_confidence:
            skipped += 1
            continue
        fn_text = extract_text_from_json(pair.field_notes_json)
        fp_text = extract_text_from_json(pair.final_report_json)
        if not fn_text or not fp_text:
            log.warning(f"Missing JSON for {pair.pair_id} — run pdf_parser.py first")
            skipped += 1
            continue
        examples.append({
            "pair_id":      pair.pair_id,
            "structure_id": pair.structure_id,
            "year":         pair.year,
            "confidence":   pair.confidence,
            "prompt": (
                f"You are a TxDOT bridge inspection report writer. "
                f"Convert these raw field notes into a formal TxDOT inspection report "
                f"for structure {pair.structure_id}.\n\n"
                f"FIELD NOTES:\n{fn_text[:3000]}\n\nFORMAL REPORT:\n"
            ),
            "completion": fp_text[:2000]
        })

    with open(output_file, "w", encoding="utf-8") as f:
        for ex in examples:
            f.write(json.dumps(ex) + "\n")

    log.info(f"SFT corpus: {len(examples)} pairs -> {output_file} ({skipped} skipped)")
    return len(examples)


def save_pairs(pairs, output_file):
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump([asdict(p) for p in pairs], f, indent=2)
    log.info(f"Saved {len(pairs)} pairs -> {output_file}")


def load_pairs(pairs_file):
    with open(pairs_file, "r", encoding="utf-8") as f:
        return [DocumentPair(**d) for d in json.load(f)]


def manual_pairing_tool(fn_dir, fp_dir, fn_json_dir, fp_json_dir, pairs_file):
    fn_pdfs = sorted(Path(fn_dir).rglob("*.pdf"))
    fp_pdfs = sorted(Path(fp_dir).rglob("*.pdf"))
    pairs = load_pairs(pairs_file) if Path(pairs_file).exists() else []
    paired = {p.field_notes_pdf for p in pairs}
    unmatched = [p for p in fn_pdfs if str(p) not in paired]

    if not unmatched:
        print("All field notes already paired!")
        return

    print(f"\nManual Pairing — {len(unmatched)} unmatched field notes")
    print("Enter number to match, Enter to skip, q to quit.\n")

    for fn_pdf in unmatched:
        print(f"\nField note: [{fn_pdf.parent.name}] {fn_pdf.name}")
        for i, fp in enumerate(fp_pdfs, 1):
            print(f"  {i:3d}. [{fp.parent.name}] {fp.name}")
        choice = input("Match: ").strip()
        if choice.lower() == 'q':
            break
        if not choice:
            continue
        try:
            fp_pdf = fp_pdfs[int(choice) - 1]
            sid = fn_pdf.parent.name
            year = extract_year(fn_pdf.name) or extract_year(fp_pdf.name)
            pairs.append(_make_pair(sid, fn_pdf, fp_pdf,
                                    Path(fn_json_dir), Path(fp_json_dir),
                                    "manual", 1.0, year))
            print(f"Paired: {fn_pdf.name} <-> {fp_pdf.name}")
        except (ValueError, IndexError):
            print("Invalid — skipping")

    save_pairs(pairs, pairs_file)


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Match field notes to final reports by bridge folder")
    sub = p.add_subparsers(dest="cmd")

    pm = sub.add_parser("match")
    pm.add_argument("--field-notes-dir",      default="./data/raw_pdfs/field_notes")
    pm.add_argument("--final-product-dir",    default="./data/raw_pdfs/final_product")
    pm.add_argument("--field-notes-parsed",   default="./data/processed/field_notes")
    pm.add_argument("--final-product-parsed", default="./data/processed/final_product")
    pm.add_argument("--pairs-output",         default="./data/pairs/pairs.json")

    pman = sub.add_parser("manual")
    pman.add_argument("--field-notes-dir",      default="./data/raw_pdfs/field_notes")
    pman.add_argument("--final-product-dir",    default="./data/raw_pdfs/final_product")
    pman.add_argument("--field-notes-parsed",   default="./data/processed/field_notes")
    pman.add_argument("--final-product-parsed", default="./data/processed/final_product")
    pman.add_argument("--pairs-file",           default="./data/pairs/pairs.json")

    pb = sub.add_parser("build")
    pb.add_argument("--pairs-file",     default="./data/pairs/pairs.json")
    pb.add_argument("--output",         default="./data/pairs/sft_pairs_corpus.jsonl")
    pb.add_argument("--min-confidence", type=float, default=0.7)

    pshow = sub.add_parser("show")
    pshow.add_argument("--pairs-file", default="./data/pairs/pairs.json")

    args = p.parse_args()

    if args.cmd == "match":
        pairs = match_by_folder(args.field_notes_dir, args.final_product_dir,
                                args.field_notes_parsed, args.final_product_parsed)
        save_pairs(pairs, args.pairs_output)
        print(f"\n{len(pairs)} pairs saved -> {args.pairs_output}")
        print("Next: python pair_builder.py show")

    elif args.cmd == "manual":
        manual_pairing_tool(args.field_notes_dir, args.final_product_dir,
                            args.field_notes_parsed, args.final_product_parsed,
                            args.pairs_file)

    elif args.cmd == "build":
        pairs = load_pairs(args.pairs_file)
        n = build_sft_corpus_from_pairs(pairs, args.output, args.min_confidence)
        print(f"\n{n} training examples -> {args.output}")

    elif args.cmd == "show":
        if not Path(args.pairs_file).exists():
            print("No pairs file. Run: python pair_builder.py match")
        else:
            pairs = load_pairs(args.pairs_file)
            print(f"\n{len(pairs)} pairs:\n")
            for pair in pairs:
                icon = "✓" if pair.confidence >= 0.9 else "~" if pair.confidence >= 0.7 else "?"
                print(f"{icon} [{pair.structure_id}] {pair.year or 'no year'} ({pair.matched_by} {pair.confidence:.2f})")
                print(f"    FN: {Path(pair.field_notes_pdf).name}")
                print(f"    FP: {Path(pair.final_report_pdf).name}\n")
            high = sum(1 for p in pairs if p.confidence >= 0.9)
            med  = sum(1 for p in pairs if 0.7 <= p.confidence < 0.9)
            low  = sum(1 for p in pairs if p.confidence < 0.7)
            print(f"Confidence summary: High={high}  Medium={med}  Low={low}")
    else:
        p.print_help()
        print("\nWorkflow: match -> show -> build")
