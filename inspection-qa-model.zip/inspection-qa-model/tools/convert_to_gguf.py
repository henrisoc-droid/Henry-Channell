"""
convert_to_gguf.py — Export trained layout model to GGUF for LM Studio
Converts layout_final.pt checkpoint to GGUF format.

Usage:
  python convert_to_gguf.py \
      --checkpoint checkpoints/layout_final.pt \
      --tokenizer  tokenizer/layout_bpe.model \
      --output-dir ./lm_studio_model \
      --llama-cpp  ./llama.cpp \
      --model-size small
"""

import os
import sys
import json
import shutil
import logging
import argparse
import subprocess
from pathlib import Path

import torch

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def export_hf_layout(checkpoint_path, tokenizer_model, hf_dir, model_config):
    """Export weights in HuggingFace-compatible layout for llama.cpp conversion."""
    os.makedirs(hf_dir, exist_ok=True)
    log.info(f"Loading checkpoint: {checkpoint_path}")
    ckpt = torch.load(checkpoint_path, map_location="cpu")
    state_dict = ckpt.get("model", ckpt)

    # Key mapping from layout model naming to LLaMA-style naming
    key_map = {
        "tok_emb.weight":  "model.embed_tokens.weight",
        "norm_f.weight":   "model.norm.weight",
        "lm_head.weight":  "lm_head.weight",
    }
    n_layers = model_config["num_hidden_layers"]
    for i in range(n_layers):
        p  = f"blocks.{i}"
        lp = f"model.layers.{i}"
        key_map.update({
            f"{p}.norm1.weight":      f"{lp}.input_layernorm.weight",
            f"{p}.norm2.weight":      f"{lp}.post_attention_layernorm.weight",
            f"{p}.attn.wq.weight":    f"{lp}.self_attn.q_proj.weight",
            f"{p}.attn.wk.weight":    f"{lp}.self_attn.k_proj.weight",
            f"{p}.attn.wv.weight":    f"{lp}.self_attn.v_proj.weight",
            f"{p}.attn.wo.weight":    f"{lp}.self_attn.o_proj.weight",
            f"{p}.ff.w1.weight":      f"{lp}.mlp.gate_proj.weight",
            f"{p}.ff.w2.weight":      f"{lp}.mlp.down_proj.weight",
            f"{p}.ff.w3.weight":      f"{lp}.mlp.up_proj.weight",
            f"{p}.norm1.weight":      f"{lp}.input_layernorm.weight",
        })

    new_sd = {}
    for k, v in state_dict.items():
        if ".lora_A" in k or ".lora_B" in k:
            continue
        k = k.replace(".linear.", ".")
        mapped = key_map.get(k, k)
        new_sd[mapped] = v

    log.info(f"Saving {len(new_sd)} tensors to {hf_dir}")
    torch.save(new_sd, os.path.join(hf_dir, "pytorch_model.bin"))

    # HuggingFace config.json
    hf_config = {
        "architectures": ["LlamaForCausalLM"],
        "bos_token_id": 2,
        "eos_token_id": 3,
        "hidden_act": "silu",
        "hidden_size": model_config["hidden_size"],
        "intermediate_size": model_config["intermediate_size"],
        "max_position_embeddings": model_config["max_position_embeddings"],
        "model_type": "llama",
        "num_attention_heads": model_config["num_attention_heads"],
        "num_hidden_layers": model_config["num_hidden_layers"],
        "num_key_value_heads": model_config["num_key_value_heads"],
        "rms_norm_eps": 1e-6,
        "rope_theta": 10000.0,
        "tie_word_embeddings": True,
        "torch_dtype": "float32",
        "vocab_size": model_config["vocab_size"],
    }
    with open(os.path.join(hf_dir, "config.json"), "w") as f:
        json.dump(hf_config, f, indent=2)

    # Tokenizer files
    shutil.copy(tokenizer_model, os.path.join(hf_dir, "tokenizer.model"))
    tok_config = {
        "bos_token": "<s>",
        "eos_token": "</s>",
        "model_max_length": model_config["max_position_embeddings"],
        "tokenizer_class": "LlamaTokenizer",
        "chat_template": (
            "{% for message in messages %}"
            "<|im_start|>{{ message['role'] }}\n{{ message['content'] }}<|im_end|>\n"
            "{% endfor %}"
            "{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}"
        )
    }
    with open(os.path.join(hf_dir, "tokenizer_config.json"), "w") as f:
        json.dump(tok_config, f, indent=2)

    log.info("HF layout exported successfully.")


def run_gguf_conversion(llama_cpp_dir, hf_dir, output_gguf, quant_type="Q4_K_M"):
    """Convert HF weights to GGUF via llama.cpp."""
    # Find converter script
    converter = None
    for name in ["convert_hf_to_gguf.py", "convert-hf-to-gguf.py",
                 "convert.py", "convert_llama_weights_to_hf.py"]:
        candidate = os.path.join(llama_cpp_dir, name)
        if os.path.exists(candidate):
            converter = candidate
            break

    if not converter:
        log.warning(
            f"llama.cpp converter not found in {llama_cpp_dir}. "
            "Saving F16 weights directly without quantization."
        )
        # Save as raw pytorch file that can be loaded directly
        shutil.copy(
            os.path.join(hf_dir, "pytorch_model.bin"),
            output_gguf.replace(".gguf", "_f16.pt")
        )
        log.info(f"Saved F16 weights: {output_gguf.replace('.gguf', '_f16.pt')}")
        return

    f16_gguf = output_gguf.replace(".gguf", "_f16.gguf")
    log.info("Step 1/2: Converting to F16 GGUF...")
    subprocess.run(
        [sys.executable, converter, hf_dir,
         "--outfile", f16_gguf, "--outtype", "f16"],
        check=True
    )

    # Quantize if binary available
    quantizer = None
    for name in ["llama-quantize", "quantize"]:
        candidate = os.path.join(llama_cpp_dir, "build", "bin", name)
        if os.path.exists(candidate):
            quantizer = candidate
            break
        candidate = os.path.join(llama_cpp_dir, name)
        if os.path.exists(candidate):
            quantizer = candidate
            break

    if not quantizer:
        log.warning("llama-quantize binary not found — skipping quantization.")
        shutil.move(f16_gguf, output_gguf)
    else:
        log.info(f"Step 2/2: Quantizing to {quant_type}...")
        subprocess.run([quantizer, f16_gguf, output_gguf, quant_type], check=True)
        os.remove(f16_gguf)

    size_mb = os.path.getsize(output_gguf) / (1024 ** 2)
    log.info(f"GGUF saved: {output_gguf} ({size_mb:.1f} MB)")


def write_model_card(output_dir, gguf_filename, model_config, quant_type):
    """Write LM Studio model card."""
    card = {
        "name": "TxDOT Bridge Inspection AI",
        "description": (
            "Domain-specialized bridge inspection model trained on TxDOT "
            "field notes, final inspection reports, and reference manuals. "
            "Fully local — no external data transmission."
        ),
        "architecture": "llama",
        "quantization": quant_type,
        "context_length": model_config["max_position_embeddings"],
        "prompt_template": "chatml",
        "system_prompt": (
            "You are a TxDOT bridge inspection expert. Answer questions "
            "accurately using standard TxDOT terminology and inspection "
            "procedures. Cite relevant manual sections where applicable."
        ),
        "parameters": {
            "temperature": 0.3,
            "top_k": 40,
            "top_p": 0.9,
            "repeat_penalty": 1.1,
            "max_tokens": 512
        },
        "files": [gguf_filename],
    }
    card_path = os.path.join(output_dir, "model.json")
    with open(card_path, "w") as f:
        json.dump(card, f, indent=2)
    log.info(f"Model card written: {card_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Export trained TxDOT layout model to GGUF for LM Studio"
    )
    parser.add_argument("--checkpoint",  required=True)
    parser.add_argument("--tokenizer",   required=True)
    parser.add_argument("--output-dir",  default="./lm_studio_model")
    parser.add_argument("--llama-cpp",   default="./llama.cpp")
    parser.add_argument("--quant",       default="Q4_K_M",
                        choices=["Q4_K_M", "Q5_K_M", "Q8_0", "F16"])
    parser.add_argument("--model-size",  default="small",
                        choices=["small", "medium", "large"])
    args = parser.parse_args()

    SIZE_CONFIGS = {
        "small": {
            "hidden_size": 768,
            "num_attention_heads": 12,
            "num_key_value_heads": 4,
            "num_hidden_layers": 12,
            "intermediate_size": 2048,
            "max_position_embeddings": 4096,
            "vocab_size": 6500,
        },
        "medium": {
            "hidden_size": 1024,
            "num_attention_heads": 16,
            "num_key_value_heads": 8,
            "num_hidden_layers": 24,
            "intermediate_size": 2730,
            "max_position_embeddings": 4096,
            "vocab_size": 6500,
        },
    }
    model_config = SIZE_CONFIGS[args.model_size]

    # Detect vocab size from checkpoint
    try:
        ckpt = torch.load(args.checkpoint, map_location="cpu")
        sd = ckpt.get("model", ckpt)
        emb = sd.get("tok_emb.weight")
        if emb is not None:
            model_config["vocab_size"] = emb.shape[0]
            log.info(f"Detected vocab_size={model_config['vocab_size']} from checkpoint")
    except Exception as e:
        log.warning(f"Could not detect vocab_size: {e}")

    os.makedirs(args.output_dir, exist_ok=True)
    hf_dir    = os.path.join(args.output_dir, "hf_weights")
    gguf_name = f"txdot-inspection-{args.model_size}-{args.quant.lower()}.gguf"
    gguf_path = os.path.join(args.output_dir, gguf_name)

    # Export HF layout
    export_hf_layout(args.checkpoint, args.tokenizer, hf_dir, model_config)

    # Convert to GGUF
    run_gguf_conversion(args.llama_cpp, hf_dir, gguf_path, args.quant)

    # Write model card
    write_model_card(args.output_dir, gguf_name, model_config, args.quant)

    print("\n" + "="*60)
    print("CONVERSION COMPLETE")
    print("="*60)
    print(f"Output directory : {os.path.abspath(args.output_dir)}")

    gguf_exists = os.path.exists(gguf_path)
    pt_exists   = os.path.exists(gguf_path.replace(".gguf", "_f16.pt"))

    if gguf_exists:
        size_mb = os.path.getsize(gguf_path) / (1024**2)
        print(f"GGUF model       : {gguf_path} ({size_mb:.1f} MB)")
    elif pt_exists:
        pt_path = gguf_path.replace(".gguf", "_f16.pt")
        size_mb = os.path.getsize(pt_path) / (1024**2)
        print(f"PyTorch weights  : {pt_path} ({size_mb:.1f} MB)")
        print("Note: llama.cpp converter not found.")
        print("Install llama.cpp to produce a .gguf file for LM Studio.")
    print(f"Model card       : {os.path.join(args.output_dir, 'model.json')}")
    print()
    print("To load in LM Studio:")
    print("  1. Open LM Studio -> My Models -> Add Model from Disk")
    print(f"  2. Point to: {os.path.abspath(args.output_dir)}")
    print("  3. Select the model file and load it")
    print()
    lm_path = os.path.join(
        os.path.expanduser("~"), ".lmstudio", "models", "custom", "txdot-inspection"
    )
    print(f"Or copy to LM Studio models directory:")
    print(f"  {lm_path}")
    print("="*60)


if __name__ == "__main__":
    main()
