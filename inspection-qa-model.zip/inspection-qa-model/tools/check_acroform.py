import json, glob

count_with, count_total = 0, 0
for path in glob.glob('data/processed/**/*.json', recursive=True):
    try:
        d = json.load(open(path, encoding='utf-8'))
    except Exception:
        continue
    count_total += 1
    af = (d.get('metadata') or {}).get('acroform_fields') or {}
    if af:
        count_with += 1
        if count_with <= 3:
            print(path, '->', list(af.items())[:5])

print(f'{count_with} / {count_total} documents have non-empty AcroForm fields')