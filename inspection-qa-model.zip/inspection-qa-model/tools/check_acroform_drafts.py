import json, glob

for path in glob.glob('data/processed/first_draft/**/*.json', recursive=True) + \
            glob.glob('data/processed/final_product/**/*.json', recursive=True):
    d = json.load(open(path, encoding='utf-8'))
    af = (d.get('metadata') or {}).get('acroform_fields') or {}
    if af:
        print(path)
        print('  sample fields:', list(af.items())[:8])
        print()