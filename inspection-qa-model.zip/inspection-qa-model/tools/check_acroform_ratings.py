import json, glob

keywords = ["rating", "deck", "superstructure", "substructure", "scour",
            "spalling", "delamination", "crack", "corrosion", "condition",
            "railing", "bearing", "joint", "recommend", "critical", "posting"]

found_any = False
for path in glob.glob('data/processed/first_draft/**/*.json', recursive=True)[:20]:
    d = json.load(open(path, encoding='utf-8'))
    af = (d.get('metadata') or {}).get('acroform_fields') or {}
    matches = {k: v for k, v in af.items() if any(kw in k.lower() for kw in keywords)}
    if matches:
        found_any = True
        print(path)
        print('  total fields:', len(af))
        print('  rating/condition matches:', matches)
        print()

if not found_any:
    print("No rating/condition-related field names found in first 20 first_draft documents.")
