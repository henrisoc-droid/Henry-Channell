import json, glob

checked = 0
found_rating_table = 0

for path in glob.glob('data/processed/first_draft/**/*.json', recursive=True):
    d = json.load(open(path, encoding='utf-8'))
    checked += 1
    for page in d.get('pages', []):
        for table in page.get('tables', []):
            cells = table.get('cells', [])
            if not cells:
                continue
            rows = {}
            for c in cells:
                rows.setdefault(c['row'], {})[c['col']] = c.get('text', '')
            if not rows:
                continue
            header = rows.get(min(rows.keys()), {})
            header_text = ' | '.join(header.values()).lower()
            if 'rating' in header_text:
                found_rating_table += 1
                print(path)
                print('  header row:', header)
                print('  n_rows:', table.get('n_rows'), 'n_cols:', table.get('n_cols'))
                print()
                break  # one example per doc is enough
    if checked >= 300 and found_rating_table >= 5:
        break  # enough samples

print(f"\nChecked {checked} documents, found {found_rating_table} with a table "
      f"header containing 'rating'.")
