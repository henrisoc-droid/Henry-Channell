import json

PATH = 'data/pairs/review_sft_corpus.jsonl'
N = 3

with open(PATH, encoding='utf-8') as f:
    lines = f.readlines()

print(f"Total examples in corpus: {len(lines)}\n")
print("=" * 70)

for i, line in enumerate(lines[:N]):
    ex = json.loads(line)
    print(f"\nEXAMPLE {i+1} — {ex.get('structure_id', '?')} ({ex.get('year', '?')})")
    print("-" * 70)
    print("COMPLETION (the QA flags the model learns to produce):")
    print(ex.get('completion', '(empty)'))
    print("=" * 70)

# Quick stats across the whole corpus
n_rating = sum(1 for l in lines if 'rating: draft states' in json.loads(l).get('completion', ''))
n_number = sum(1 for l in lines if '[NUMBER/RATING]' in json.loads(l).get('completion', ''))
n_status = sum(1 for l in lines if '[STATUS/CATEGORY]' in json.loads(l).get('completion', ''))
n_recomm = sum(1 for l in lines if '[RECOMMENDATION]' in json.loads(l).get('completion', ''))

print(f"\nCORPUS STATS ({len(lines)} examples):")
print(f"  contain a component rating comparison : {n_rating}")
print(f"  contain [NUMBER/RATING] flags         : {n_number}")
print(f"  contain [STATUS/CATEGORY] flags       : {n_status}")
print(f"  contain [RECOMMENDATION] flags        : {n_recomm}")
