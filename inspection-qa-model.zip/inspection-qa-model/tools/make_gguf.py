"""
make_gguf.py — Direct GGUF conversion for TxDOT layout model
Run: python make_gguf.py
"""
import torch
import os
import sys

print("Step 1: Installing gguf package...")
os.system(f"{sys.executable} -m pip install gguf --break-system-packages -q")

print("Step 2: Loading checkpoint...")
ckpt = torch.load("checkpoints/layout_final.pt", map_location="cpu")
sd = ckpt.get("model", ckpt)
print(f"  Loaded {len(sd)} tensors")

print("Step 3: Converting to GGUF...")
from gguf import GGUFWriter

output = "lm_studio_model/txdot-inspection.gguf"
os.makedirs("lm_studio_model", exist_ok=True)

writer = GGUFWriter(output, "llama")

# Metadata
writer.add_name("TxDOT Bridge Inspection AI")
writer.add_description("TxDOT bridge inspection model — field notes, reports, manuals")
writer.add_uint32("llama.context_length", 512)
writer.add_uint32("llama.embedding_length", 768)
writer.add_uint32("llama.block_count", 12)
writer.add_uint32("llama.attention.head_count", 12)
writer.add_uint32("llama.attention.head_count_kv", 4)
writer.add_float32("llama.attention.layer_norm_rms_epsilon", 1e-6)
writer.add_uint32("llama.feed_forward_length", 2048)
writer.add_uint32("general.file_type", 1)
writer.add_bos_token_id(2)
writer.add_eos_token_id(3)
writer.add_pad_token_id(0)

# Tensor name mapping
key_map = {
    "tok_emb.weight":  "token_embd.weight",
    "norm_f.weight":   "output_norm.weight",
    "lm_head.weight":  "output.weight",
}
for i in range(12):
    key_map.update({
        f"blocks.{i}.norm1.weight":   f"blk.{i}.attn_norm.weight",
        f"blocks.{i}.norm2.weight":   f"blk.{i}.ffn_norm.weight",
        f"blocks.{i}.attn.wq.weight": f"blk.{i}.attn_q.weight",
        f"blocks.{i}.attn.wk.weight": f"blk.{i}.attn_k.weight",
        f"blocks.{i}.attn.wv.weight": f"blk.{i}.attn_v.weight",
        f"blocks.{i}.attn.wo.weight": f"blk.{i}.attn_output.weight",
        f"blocks.{i}.ff.w1.weight":   f"blk.{i}.ffn_gate.weight",
        f"blocks.{i}.ff.w2.weight":   f"blk.{i}.ffn_down.weight",
        f"blocks.{i}.ff.w3.weight":   f"blk.{i}.ffn_up.weight",
    })

# Write tensors
written = 0
skipped = []
for k, v in sd.items():
    mapped = key_map.get(k)
    if mapped:
        arr = v.float().numpy()
        writer.add_tensor(mapped, arr)
        written += 1
        print(f"  + {mapped} {list(v.shape)}")
    else:
        skipped.append(k)

if skipped:
    print(f"\n  Skipped {len(skipped)} unmapped tensors:")
    for s in skipped[:5]:
        print(f"    - {s}")

print(f"\nStep 4: Writing GGUF file...")
writer.write_header_to_file()
writer.write_kv_data_to_file()
writer.write_tensors_to_file()
writer.close()

size_mb = os.path.getsize(output) / 1024 / 1024
print(f"\nDone!")
print(f"Output: {output}")
print(f"Size:   {size_mb:.1f} MB")
print(f"Tensors written: {written}")
print("\nTo load in LM Studio:")
print("  1. Open LM Studio -> My Models -> Add Model from Disk")
print(f"  2. Point to: lm_studio_model/")
print("  3. Select txdot-inspection.gguf")
