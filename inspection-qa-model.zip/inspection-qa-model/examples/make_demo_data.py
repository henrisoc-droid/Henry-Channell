"""
make_demo_data.py — Generate SYNTHETIC inspection documents for a runnable demo.

Nothing here is real. Bridge IDs use the 00-000-0000-00-NNN placeholder range,
and every note, rating, and comment is invented. The point is to let anyone run
the full pipeline (parse -> pair -> corpus -> tokenizer -> train) without access
to real inspection records, which are confidential and never included in this repo.

For each fake bridge this writes:
  data/raw_pdfs/field_notes/<ID>/<ID> Combined Field Notes 2025.pdf   (shorthand notes)
  data/raw_pdfs/final_product/<ID>/<ID> RTInsp 2025.pdf               (polished report)
plus a small reference guide in manuals/raw/ for the retrieval (RAG) demo.

Some final reports deliberately disagree with the field notes (e.g. a component
rating changed during review) so the pairs contain the kind of discrepancy the
QA model is meant to flag.

Usage (from the repository root):
    python examples/make_demo_data.py
"""

import random
from pathlib import Path

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.lib import colors

random.seed(7)
STYLES = getSampleStyleSheet()
BANNER = "SYNTHETIC SAMPLE DOCUMENT - FOR DEMONSTRATION ONLY - NOT A REAL INSPECTION"

# (component, field-note shorthand, final-report wording, field rating, final rating)
COMPONENTS = [
    ("Deck", "DECK lngitudnal crk nr brng seat w/ efflor, minor spall 1sf",
     "Longitudinal cracking observed near the bearing seat with efflorescence; minor spalling, approximately 1 sq ft.", 6, 6),
    ("Superstructure", "SUPER prestr bms ok, hairline crk bm 3 midspan",
     "Prestressed concrete beams in satisfactory condition; hairline crack noted at midspan of Beam 3.", 7, 6),
    ("Substructure", "SUB bent 2 cap spall exp rebar ~2sf, sect loss minor",
     "Spalling with exposed reinforcing steel at the Bent 2 cap, approximately 2 sq ft, with minor section loss.", 5, 5),
    ("Channel", "CHNL minor scour @ abut 1, riprap displaced",
     "Minor scour observed at Abutment 1; riprap partially displaced.", 6, 6),
    ("Bearings", "BRGS elastomeric bulging slight @ bent 2",
     "Elastomeric bearings show slight bulging at Bent 2.", 7, 7),
]


def on_page(canvas, doc):
    """Repeat a banner on every page -- exercises the parser's boilerplate stripping."""
    canvas.saveState()
    canvas.setFont("Helvetica-Bold", 8)
    canvas.drawCentredString(letter[0] / 2, letter[1] - 30, BANNER)
    canvas.restoreState()


def rating_table(rows):
    t = Table([["Element / Component", "Rating", "Comment"]] + rows, colWidths=[120, 50, 300])
    t.setStyle(TableStyle([
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return t


def wrap(text):
    return Paragraph(text, STYLES["BodyText"])


def make_bridge(root: Path, idx: int):
    sid = f"00-000-0000-00-{idx:03d}"
    comps = random.sample(COMPONENTS, k=4)
    # Plant an extra reviewer change on some bridges: final rating differs from field rating.
    planted = []
    for c in comps:
        name, note, final, fr, pr = c
        if fr == pr and random.random() < 0.3:
            pr = fr - 1
        planted.append((name, note, final, fr, pr))

    fn_dir = root / "data/raw_pdfs/field_notes" / sid
    fp_dir = root / "data/raw_pdfs/final_product" / sid
    fn_dir.mkdir(parents=True, exist_ok=True)
    fp_dir.mkdir(parents=True, exist_ok=True)

    # Field notes: terse shorthand, ratings as the inspector recorded them in the field.
    story = [Paragraph(f"FIELD NOTES - Structure {sid}", STYLES["Title"]),
             Paragraph("Insp date: 2025-06-1%d   Weather: clear   Insp: Inspector A" % idx, STYLES["BodyText"]),
             Spacer(1, 10)]
    for page, chunk in enumerate([planted[:2], planted[2:]]):
        for name, note, _, fr, _ in chunk:
            story += [Paragraph(f"{name.upper()}:", STYLES["Heading3"]), wrap(note), Spacer(1, 6)]
        story += [rating_table([[n, str(fr), wrap(note)] for n, note, _, fr, _ in chunk]), PageBreak()]
    story += [Paragraph("Follow-up: monitor items above at next routine insp.", STYLES["BodyText"])]
    SimpleDocTemplate(str(fn_dir / f"{sid} Combined Field Notes 2025.pdf"), pagesize=letter).build(
        story, onFirstPage=on_page, onLaterPages=on_page)

    # Final report: formal prose and the reviewed ratings.
    story = [Paragraph(f"ROUTINE INSPECTION REPORT - Structure {sid}", STYLES["Title"]),
             Paragraph("Inspection Date: June 1%d, 2025. Inspection Type: Routine." % idx, STYLES["BodyText"]),
             Spacer(1, 10)]
    for page, chunk in enumerate([planted[:2], planted[2:]]):
        for name, _, final, _, pr in chunk:
            story += [Paragraph(name, STYLES["Heading3"]), wrap(final), Spacer(1, 6)]
        story += [rating_table([[n, str(pr), wrap(final)] for n, _, final, _, pr in chunk]), PageBreak()]
    story += [Paragraph("Recommendations: Monitor noted deficiencies at the next routine inspection.",
                        STYLES["BodyText"])]
    SimpleDocTemplate(str(fp_dir / f"{sid} RTInsp 2025.pdf"), pagesize=letter).build(
        story, onFirstPage=on_page, onLaterPages=on_page)

    changed = [(n, fr, pr) for n, _, _, fr, pr in planted if fr != pr]
    return sid, changed


def make_guide(root: Path):
    """A tiny invented reference guide with numbered sections, for the RAG demo."""
    out = root / "manuals/raw"
    out.mkdir(parents=True, exist_ok=True)
    sections = [
        ("1.1 Purpose", "This sample guide describes how condition ratings shall be assigned during routine inspection."),
        ("2.1 Deck Condition Rating", "The deck rating must reflect the worst condition observed. Spalling and delamination "
         "shall be quantified in square feet and recorded with location."),
        ("2.2 Superstructure Condition Rating", "Cracking in prestressed beams must be documented by beam number and location. "
         "A change in rating from the previous inspection shall be explained in the comments."),
        ("2.3 Substructure Condition Rating", "Exposed reinforcing steel with section loss shall be noted and photographed. "
         "Spalling at bent caps must be measured and its area recorded."),
        ("3.1 Scour and Channel", "Displaced riprap and scour at abutments shall be documented and monitored at each inspection."),
    ]
    story = [Paragraph("Sample Inspection Reference Guide (Synthetic)", STYLES["Title"])]
    for head, body in sections:
        story += [Paragraph(head, STYLES["Heading2"]), wrap(body), Spacer(1, 8)]
    SimpleDocTemplate(str(out / "sample_inspection_guide.pdf"), pagesize=letter).build(story)


if __name__ == "__main__":
    root = Path(".")
    summary = [make_bridge(root, i) for i in range(1, 7)]
    make_guide(root)
    print(f"Wrote {len(summary)} synthetic bridges (field notes + final report each) and a sample guide.")
    for sid, changed in summary:
        note = ", ".join(f"{n} {a}->{b}" for n, a, b in changed) or "no rating changes"
        print(f"  {sid}: {note}")
