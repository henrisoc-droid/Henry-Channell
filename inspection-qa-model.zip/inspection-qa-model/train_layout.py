"""
train_layout.py — Training script for the Layout-Aware PDF Model
Two phases:
  Phase 1: Pretraining on layout token corpus (all PDF pages)
  Phase 2: SFT on labeled instruction pairs

Usage:
  # Phase 1 - pretraining
  python train_layout.py pretrain \
      --corpus data/pretrain_corpus.txt \
      --tokenizer tokenizer/layout_bpe.model \
      --config small --max-steps 50000

  # Phase 2 - SFT
  python train_layout.py sft \
      --corpus data/sft_corpus.txt \
      --tokenizer tokenizer/layout_bpe.model \
      --resume checkpoints/layout_best.pt
"""

import os
import time
import math
import json
import logging
import argparse
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Optional, List

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, random_split

os.environ["HF_DATASETS_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"

from layout_model import LayoutLM, LAYOUT_CONFIGS, LayoutModelConfig, BLOCK_TYPE_MAP
from layout_tokenizer import LayoutBPETokenizer, PDFLayoutTokenizer

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler("train_layout.log")]
)
log = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# Token metadata extractor
# (parses layout tokens back into spatial metadata)
# ──────────────────────────────────────────────

def extract_layout_metadata(token_ids: List[int], sp_model) -> dict:
    """
    Given a list of token IDs, extract spatial and layout metadata
    for each position. Returns parallel arrays for x_zones, y_zones,
    block_types, font_sizes, styles.
    """
    T = len(token_ids)
    x_zones    = [5] * T   # default center
    y_zones    = [5] * T
    block_types = [0] * T  # default "text"
    font_sizes  = [1] * T  # default "normal"
    styles      = [0] * T  # default none

    # Decode tokens and parse special tags
    current_x, current_y = 5, 5
    current_bt = 0
    current_fs = 1
    current_style = 0

    for i, tid in enumerate(token_ids):
        piece = sp_model.decode([tid]) if hasattr(sp_model, 'decode') else ""

        # Parse X/Y zone tokens
        if piece.startswith("[X") and piece.endswith("]"):
            try: current_x = int(piece[2:-1])
            except: pass
        elif piece.startswith("[Y") and piece.endswith("]"):
            try: current_y = int(piece[2:-1])
            except: pass
        elif piece == "[HEADER]":
            current_bt = BLOCK_TYPE_MAP["header"]
        elif piece == "[TABLE]":
            current_bt = BLOCK_TYPE_MAP["table"]
        elif piece == "[CELL]":
            current_bt = BLOCK_TYPE_MAP["table_cell"]
        elif piece in ("[/HEADER]", "[/TABLE]", "[/CELL]", "[TEXT]", "[/TEXT]"):
            current_bt = BLOCK_TYPE_MAP["text"]
        elif piece == "[FIELD]":
            current_bt = BLOCK_TYPE_MAP["form_field"]
        elif piece == "[BOLD]":
            current_style = min(current_style | 1, 3)
        elif piece == "[/BOLD]":
            current_style = current_style & ~1
        elif piece == "[ITALIC]":
            current_style = min(current_style | 2, 3)
        elif piece == "[/ITALIC]":
            current_style = current_style & ~2
        elif piece == "[FS_SMALL]":   current_fs = 0
        elif piece == "[FS_NORMAL]":  current_fs = 1
        elif piece == "[FS_LARGE]":   current_fs = 2
        elif piece == "[FS_TITLE]":   current_fs = 3
        elif piece == "[PAGE_START]": current_bt = BLOCK_TYPE_MAP["page_start"]
        elif piece == "[PAGE_END]":   current_bt = BLOCK_TYPE_MAP["page_end"]

        x_zones[i]     = current_x
        y_zones[i]     = current_y
        block_types[i] = current_bt
        font_sizes[i]  = current_fs
        styles[i]      = current_style

    return {
        "x_zones":    x_zones,
        "y_zones":    y_zones,
        "block_types": block_types,
        "font_sizes": font_sizes,
        "styles":     styles,
    }


# ──────────────────────────────────────────────
# Dataset
# ──────────────────────────────────────────────

class LayoutCorpusDataset(Dataset):
    """
    Dataset for the layout token corpus.
    Each line in the corpus is a full document token sequence.
    We chunk into max_seq_len windows for training.
    """
    def __init__(self, corpus_file: str, tokenizer: LayoutBPETokenizer,
                 max_seq_len: int = 4096, cache_file: str = ""):
        import numpy as np
        self.max_seq_len = max_seq_len
        self.tok = tokenizer
        cache = cache_file or corpus_file + ".cache.npy"

        if os.path.exists(cache):
            log.info(f"Loading cached tokens: {cache}")
            self.tokens = np.load(cache, mmap_mode="r")
        else:
            log.info(f"Tokenizing corpus: {corpus_file}")
            all_tokens = []
            with open(corpus_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        toks = tokenizer.encode(line)
                        all_tokens.extend(toks)
            self.tokens = np.array(all_tokens, dtype=np.uint16)
            np.save(cache, self.tokens)
            log.info(f"Cached {len(self.tokens):,} tokens → {cache}")

    def __len__(self):
        return max(0, len(self.tokens) - self.max_seq_len)

    def __getitem__(self, idx):
        chunk = self.tokens[idx: idx + self.max_seq_len + 1].astype("int32")
        x = torch.tensor(chunk[:-1], dtype=torch.long)
        y = torch.tensor(chunk[1:],  dtype=torch.long)
        return x, y


# ──────────────────────────────────────────────
# LR Schedule
# ──────────────────────────────────────────────

def get_lr(step: int, max_steps: int, max_lr: float, warmup_steps: int) -> float:
    if step < warmup_steps:
        return max_lr * step / warmup_steps
    progress = (step - warmup_steps) / max(1, max_steps - warmup_steps)
    return max_lr * 0.5 * (1.0 + math.cos(math.pi * progress))


# ──────────────────────────────────────────────
# SFT Dataset (with prompt masking)
# ──────────────────────────────────────────────

class SFTInstructionDataset(Dataset):
    """
    Dataset for SFT instruction examples, matching the JSONL format
    produced by pair_builder.py's build_sft_corpus_from_pairs():
        {"prompt": "...", "completion": "...", ...other metadata}
    Each example's prompt and completion are tokenized separately and
    concatenated, so we know the exact boundary between them without
    needing a literal [SEP] token in the text. Loss is masked over the
    prompt portion — only the completion (the actual formal report
    text) contributes to the training signal. This is what prevents
    the model from being rewarded for learning to echo the input
    field notes instead of generating real analysis.
    """
    def __init__(self, corpus_file: str, tokenizer: LayoutBPETokenizer,
                 max_seq_len: int = 2048):
        self.tok = tokenizer
        self.max_seq_len = max_seq_len

        self.examples = []
        skipped_bad_json, skipped_empty, skipped_too_long = 0, 0, 0

        with open(corpus_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    ex = json.loads(line)
                except json.JSONDecodeError:
                    skipped_bad_json += 1
                    continue

                prompt = ex.get("prompt", "")
                completion = ex.get("completion", "")
                if not prompt or not completion:
                    skipped_empty += 1
                    continue

                prompt_ids = tokenizer.encode(prompt)
                completion_ids = tokenizer.encode(completion)
                # Append EOS if the tokenizer defines one, so generation
                # learns to stop instead of running to max_new_tokens.
                if tokenizer.eos_id is not None and tokenizer.eos_id >= 0:
                    completion_ids = completion_ids + [tokenizer.eos_id]

                # If the combined sequence is too long, truncate the PROMPT
                # from the front — always keep the full completion intact,
                # since that's the only part loss is computed on.
                total_len = len(prompt_ids) + len(completion_ids)
                if total_len > self.max_seq_len + 1:
                    keep_prompt = (self.max_seq_len + 1) - len(completion_ids)
                    if keep_prompt <= 0:
                        # Completion alone is already too long — skip.
                        skipped_too_long += 1
                        continue
                    prompt_ids = prompt_ids[-keep_prompt:]

                ids = prompt_ids + completion_ids
                prompt_len = len(prompt_ids)
                self.examples.append((ids, prompt_len))

        if skipped_bad_json:
            log.warning(f"Skipped {skipped_bad_json} lines with invalid JSON")
        if skipped_empty:
            log.warning(f"Skipped {skipped_empty} examples with empty prompt/completion")
        if skipped_too_long:
            log.warning(f"Skipped {skipped_too_long} examples whose completion "
                        f"alone exceeded max_seq_len={max_seq_len}")
        log.info(f"SFT dataset: {len(self.examples)} usable examples")

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        ids, prompt_len = self.examples[idx]
        x = torch.tensor(ids[:-1], dtype=torch.long)
        y = torch.tensor(ids[1:],  dtype=torch.long)

        # Mask every target position that falls within the prompt —
        # loss is only computed on the completion that follows it.
        # (prompt_len - 1 because y is shifted left by one relative to ids)
        mask_upto = max(0, prompt_len - 1)
        y[:mask_upto] = -100
        return x, y


# ──────────────────────────────────────────────
# Trainer
# ──────────────────────────────────────────────

class LayoutTrainer:
    def __init__(self, model_size: str, tokenizer_path: str,
                 checkpoint_dir: str = "./checkpoints",
                 resume_from: str = "", dtype: str = "float32"):

        torch.manual_seed(42)
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

        self.device = (
            torch.device("cuda") if torch.cuda.is_available() else
            torch.device("mps")  if torch.backends.mps.is_available() else
            torch.device("cpu")
        )
        log.info(f"Device: {self.device}")

        self.dtype_map = {"float32": torch.float32, "bfloat16": torch.bfloat16}
        self.dtype = self.dtype_map.get(dtype, torch.float32)
        self.use_amp = (dtype == "bfloat16") and str(self.device) == "cuda"

        # Tokenizer
        log.info(f"Loading tokenizer: {tokenizer_path}")
        self.tokenizer = LayoutBPETokenizer(tokenizer_path)

        # Model
        cfg = LAYOUT_CONFIGS[model_size]
        cfg.vocab_size = self.tokenizer.vocab_size
        self.model = LayoutLM(cfg).to(self.device)
        log.info(f"Model: {model_size} — {self.model.count_parameters():,} parameters")

        # Optimizer
        self.step = 0
        self.best_val_loss = float("inf")
        self.optimizer = self._build_optimizer(lr=3e-4)

        if resume_from:
            self._load(resume_from)

    def _build_optimizer(self, lr: float):
        decay, no_decay = [], []
        for name, p in self.model.named_parameters():
            if not p.requires_grad: continue
            if p.ndim >= 2 and "bias" not in name and "norm" not in name:
                decay.append(p)
            else:
                no_decay.append(p)
        return torch.optim.AdamW(
            [{"params": decay, "weight_decay": 0.1},
             {"params": no_decay, "weight_decay": 0.0}],
            lr=lr, betas=(0.9, 0.95),
            fused=(str(self.device) == "cuda")
        )

    def _save(self, tag: str = ""):
        name = "layout_" + (tag if tag else str(self.step).zfill(7)) + ".pt"
        path = self.checkpoint_dir / name
        torch.save({
            "step": self.step,
            "model": self.model.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "val_loss": self.best_val_loss,
        }, path)
        log.info(f"Checkpoint saved: {path}")
        # Keep last 3
        ckpts = sorted(self.checkpoint_dir.glob("layout_*.pt"))
        for old in ckpts[:-3]:
            if "best" not in old.name and "final" not in old.name:
                old.unlink(missing_ok=True)

    def _load(self, path: str):
        log.info(f"Resuming from: {path}")
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["model"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self.step = ckpt.get("step", 0)
        self.best_val_loss = ckpt.get("val_loss", float("inf"))
        log.info(f"Resumed at step {self.step}")

    @torch.no_grad()
    def evaluate(self, loader: DataLoader, eval_steps: int = 50) -> float:
        self.model.eval()
        total, n = 0.0, 0
        for i, (x, y) in enumerate(loader):
            if i >= eval_steps: break
            x, y = x.to(self.device), y.to(self.device)
            with torch.autocast(str(self.device).split(":")[0], self.dtype, enabled=self.use_amp):
                _, loss = self.model(x, targets=y)
            total += loss.item(); n += 1
        self.model.train()
        return total / max(n, 1)

    def train(self, train_loader: DataLoader, val_loader: DataLoader,
              max_steps: int = 50000, grad_accum: int = 4,
              max_lr: float = 3e-4, warmup_steps: int = 1000,
              eval_interval: int = 500, save_interval: int = 500,
              log_interval: int = 10, grad_clip: float = 1.0):

        log.info(f"Starting training — max_steps={max_steps}")
        self.model.train()
        device_type = str(self.device).split(":")[0]
        scaler = torch.cuda.amp.GradScaler(enabled=(self.dtype == torch.float16))

        start_step = self.step  # LR schedule runs fresh from here, not from
                                 # the absolute resumed step count — otherwise
                                 # resuming near max_steps puts us instantly
                                 # in the decay tail with a near-zero LR.
        raw_loss, grad_steps = 0.0, 0
        t0 = time.time()

        while self.step < max_steps:
            for x, y in train_loader:
                if self.step >= max_steps:
                    break

                x, y = x.to(self.device), y.to(self.device)

                lr = get_lr(self.step - start_step, max_steps - start_step, max_lr, warmup_steps)
                for pg in self.optimizer.param_groups:
                    pg["lr"] = lr

                with torch.autocast(device_type, self.dtype, enabled=self.use_amp):
                    _, loss = self.model(x, targets=y)
                    loss = loss / grad_accum

                scaler.scale(loss).backward()
                raw_loss += loss.item() * grad_accum
                grad_steps += 1

                if grad_steps % grad_accum == 0:
                    scaler.unscale_(self.optimizer)
                    nn.utils.clip_grad_norm_(self.model.parameters(), grad_clip)
                    scaler.step(self.optimizer)
                    scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
                    self.step += 1

                    if self.step % log_interval == 0:
                        dt = time.time() - t0
                        tok_s = (log_interval * x.shape[0] * x.shape[1]) / dt
                        log.info(f"step={self.step:6d} | loss={raw_loss/log_interval:.4f} | lr={lr:.2e} | tok/s={tok_s:.0f}")
                        raw_loss = 0.0
                        t0 = time.time()

                    if self.step % eval_interval == 0:
                        val_loss = self.evaluate(val_loader)
                        log.info(f"=== Validation step={self.step} val_loss={val_loss:.4f} ===")
                        if val_loss < self.best_val_loss:
                            self.best_val_loss = val_loss
                            self._save("best")

                    if self.step % save_interval == 0:
                        self._save()

        log.info("Training complete.")
        self._save("final")


# ──────────────────────────────────────────────
# Collate (module-level so Windows spawn-based
# multiprocessing can pickle it — nested functions
# defined inside main() cannot be pickled)
# ──────────────────────────────────────────────

def collate(batch):
    xs, ys = zip(*batch)
    max_l = max(x.size(0) for x in xs)
    xp = torch.stack([F.pad(x, (0, max_l - x.size(0))) for x in xs])
    yp = torch.stack([F.pad(y, (0, max_l - y.size(0)), value=-100) for y in ys])
    return xp, yp


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Train layout-aware PDF model")
    sub = parser.add_subparsers(dest="phase")

    # Pretrain
    p1 = sub.add_parser("pretrain")
    p1.add_argument("--corpus",       required=True)
    p1.add_argument("--tokenizer",    required=True)
    p1.add_argument("--config",       default="small", choices=["small","medium","large"])
    p1.add_argument("--checkpoint-dir", default="./checkpoints")
    p1.add_argument("--resume-from",  default="")
    p1.add_argument("--max-steps",    type=int,   default=50000)
    p1.add_argument("--batch-size",   type=int,   default=4)
    p1.add_argument("--grad-accum",   type=int,   default=8)
    p1.add_argument("--max-seq-len",  type=int,   default=2048)
    p1.add_argument("--learning-rate",type=float, default=3e-4)
    p1.add_argument("--dtype",        default="float32", choices=["float32","bfloat16"])

    # SFT
    p2 = sub.add_parser("sft")
    p2.add_argument("--corpus",       required=True)
    p2.add_argument("--tokenizer",    required=True)
    p2.add_argument("--resume-from",  required=True, help="Pretrained checkpoint to start from")
    p2.add_argument("--config",       default="small")
    p2.add_argument("--checkpoint-dir", default="./checkpoints")
    p2.add_argument("--max-steps",    type=int,   default=5000)
    p2.add_argument("--batch-size",   type=int,   default=2)
    p2.add_argument("--grad-accum",   type=int,   default=4)
    p2.add_argument("--max-seq-len",  type=int,   default=2048)
    p2.add_argument("--learning-rate",type=float, default=1e-5)
    p2.add_argument("--dtype",        default="float32")

    args = parser.parse_args()
    if not args.phase:
        parser.print_help(); return

    trainer = LayoutTrainer(
        model_size=args.config,
        tokenizer_path=args.tokenizer,
        checkpoint_dir=args.checkpoint_dir,
        resume_from=args.resume_from,
        dtype=args.dtype
    )

    log.info(f"Loading corpus: {args.corpus}")
    if args.phase == "sft":
        dataset = SFTInstructionDataset(args.corpus, trainer.tokenizer, args.max_seq_len)
    else:
        dataset = LayoutCorpusDataset(args.corpus, trainer.tokenizer, args.max_seq_len)
    n_val = min(50, max(5, int(0.10 * len(dataset))))
    n_train = len(dataset) - n_val
    train_ds, val_ds = random_split(dataset, [n_train, n_val],
                                     generator=torch.Generator().manual_seed(42))
    log.info(f"Dataset: train={n_train:,} val={n_val:,}")

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=0, collate_fn=collate)
    val_loader   = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                              num_workers=0, collate_fn=collate)

    new_steps = max(1, args.max_steps - trainer.step)
    trainer.train(
        train_loader, val_loader,
        max_steps=args.max_steps,
        grad_accum=args.grad_accum,
        max_lr=args.learning_rate,
        warmup_steps=max(10, new_steps // 20)
    )


if __name__ == "__main__":
    main()
