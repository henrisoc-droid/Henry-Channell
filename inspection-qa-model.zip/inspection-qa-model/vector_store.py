"""
vector_store.py — Local Vector Database (fully offline)
Builds TF-IDF + semantic embeddings of manual sections.
Stores everything in SQLite + numpy — no external services.

Two embedding strategies:
  1. TF-IDF (fast, no GPU needed, works immediately)
  2. Sentence embeddings via a tiny local model (better quality, optional)

Install: pip install scikit-learn numpy --break-system-packages
"""

import os
import json
import sqlite3
import logging
import pickle
import hashlib
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False
    log.warning("scikit-learn not found. Install: pip install scikit-learn --break-system-packages")


# ──────────────────────────────────────────────
# Search result
# ──────────────────────────────────────────────

@dataclass
class SearchResult:
    manual_name:    str
    section_number: str
    section_title:  str
    content:        str
    page_start:     int
    element_tags:   List[str]
    keywords:       List[str]
    score:          float
    citation:       str  # formatted citation string


# ──────────────────────────────────────────────
# TF-IDF Vector Store
# ──────────────────────────────────────────────

class TFIDFVectorStore:
    """
    Fast local vector store using TF-IDF embeddings.
    No GPU required. Runs on any machine.
    Searches thousands of manual sections in milliseconds.
    """

    def __init__(self, store_path: str = "./vector_store"):
        self.store_path = Path(store_path)
        self.store_path.mkdir(parents=True, exist_ok=True)
        self.db_path = self.store_path / "manual_store.db"
        self.index_path = self.store_path / "tfidf_index.pkl"

        self.vectorizer = None
        self.tfidf_matrix = None
        self.section_ids = []

        self._init_db()

        # Load existing index if available
        if self.index_path.exists():
            self._load_index()

    def _init_db(self):
        """Initialize SQLite database for section metadata."""
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sections (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                manual_name     TEXT,
                section_number  TEXT,
                section_title   TEXT,
                content         TEXT,
                page_start      INTEGER,
                page_end        INTEGER,
                level           INTEGER,
                keywords        TEXT,
                element_tags    TEXT,
                parent_section  TEXT,
                content_hash    TEXT UNIQUE
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_manual ON sections(manual_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_section ON sections(section_number)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_elements ON sections(element_tags)")
        conn.commit()
        conn.close()

    def _content_hash(self, content: str) -> str:
        return hashlib.md5(content.encode()).hexdigest()

    def add_sections(self, sections: List[Dict], rebuild_index: bool = True):
        """Add manual sections to the database."""
        conn = sqlite3.connect(str(self.db_path))
        added = 0
        skipped = 0

        for s in sections:
            content = s.get("content", "")
            if not content or len(content) < 30:
                continue

            chash = self._content_hash(content)
            try:
                conn.execute("""
                    INSERT OR IGNORE INTO sections
                    (manual_name, section_number, section_title, content,
                     page_start, page_end, level, keywords, element_tags,
                     parent_section, content_hash)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    s.get("manual_name", ""),
                    s.get("section_number", ""),
                    s.get("section_title", ""),
                    content,
                    s.get("page_start", 0),
                    s.get("page_end", 0),
                    s.get("level", 1),
                    json.dumps(s.get("keywords", [])),
                    json.dumps(s.get("element_tags", [])),
                    s.get("parent_section", ""),
                    chash
                ))
                added += 1
            except Exception as e:
                skipped += 1
                log.debug(f"Skipping duplicate section: {e}")

        conn.commit()
        conn.close()
        log.info(f"Added {added} sections ({skipped} duplicates skipped)")

        if rebuild_index and added > 0:
            self.build_index()

    def build_index(self):
        """Build TF-IDF index from all sections in the database."""
        if not HAS_SKLEARN:
            raise ImportError("scikit-learn required: pip install scikit-learn --break-system-packages")

        conn = sqlite3.connect(str(self.db_path))
        rows = conn.execute(
            "SELECT id, section_title, content, keywords FROM sections ORDER BY id"
        ).fetchall()
        conn.close()

        if not rows:
            log.warning("No sections in database to index")
            return

        log.info(f"Building TF-IDF index for {len(rows)} sections...")

        self.section_ids = [r[0] for r in rows]

        # Combine title + keywords + content for richer matching
        texts = []
        for _, title, content, keywords_json in rows:
            kw = " ".join(json.loads(keywords_json) if keywords_json else [])
            # Weight title and keywords more by repeating them
            texts.append(f"{title} {title} {kw} {kw} {content}")

        # TF-IDF with n-grams for better phrase matching
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 3),
            max_features=50000,
            sublinear_tf=True,
            min_df=1,
            analyzer='word',
            token_pattern=r'\b[a-zA-Z][a-zA-Z0-9\-\.]*\b'
        )
        self.tfidf_matrix = self.vectorizer.fit_transform(texts)

        # Save index
        with open(self.index_path, "wb") as f:
            pickle.dump({
                "vectorizer": self.vectorizer,
                "matrix": self.tfidf_matrix,
                "section_ids": self.section_ids
            }, f)

        log.info(f"Index built and saved — {len(self.section_ids)} sections, "
                 f"{self.tfidf_matrix.shape[1]} features")

    def _load_index(self):
        """Load existing TF-IDF index from disk."""
        try:
            with open(self.index_path, "rb") as f:
                data = pickle.load(f)
            self.vectorizer    = data["vectorizer"]
            self.tfidf_matrix  = data["matrix"]
            self.section_ids   = data["section_ids"]
            log.info(f"Loaded TF-IDF index — {len(self.section_ids)} sections")
        except Exception as e:
            log.warning(f"Could not load index: {e} — will rebuild")

    def search(self, query: str, top_k: int = 5,
               element_filter: Optional[str] = None,
               manual_filter: Optional[str] = None) -> List[SearchResult]:
        """
        Search for the most relevant manual sections for a given query.

        Args:
            query: The inspection finding or question to search for
            top_k: Number of results to return
            element_filter: Only return sections about this element (e.g. "deck")
            manual_filter: Only search within a specific manual
        """
        if self.vectorizer is None or self.tfidf_matrix is None:
            log.warning("Index not built. Run build_index() first.")
            return []

        # Vectorize query
        query_vec = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vec, self.tfidf_matrix).flatten()

        # Get top candidates (get more than top_k to allow filtering)
        top_indices = np.argsort(scores)[::-1][:top_k * 5]

        # Fetch section metadata from DB
        conn = sqlite3.connect(str(self.db_path))
        results = []

        for idx in top_indices:
            if len(results) >= top_k:
                break
            if scores[idx] < 0.01:
                break

            section_id = self.section_ids[idx]
            row = conn.execute(
                "SELECT manual_name, section_number, section_title, content, "
                "page_start, element_tags, keywords FROM sections WHERE id=?",
                (section_id,)
            ).fetchone()

            if not row:
                continue

            manual_name, sec_num, title, content, page_start, elem_json, kw_json = row
            element_tags = json.loads(elem_json) if elem_json else []
            keywords     = json.loads(kw_json)   if kw_json   else []

            # Apply filters
            if element_filter and element_filter.lower() not in element_tags:
                continue
            if manual_filter and manual_filter.lower() not in manual_name.lower():
                continue

            # Build citation string
            citation = _format_citation(manual_name, sec_num, title, page_start)

            results.append(SearchResult(
                manual_name=manual_name,
                section_number=sec_num,
                section_title=title,
                content=content[:1000],  # truncate for injection
                page_start=page_start,
                element_tags=element_tags,
                keywords=keywords,
                score=float(scores[idx]),
                citation=citation
            ))

        conn.close()
        return results

    def keyword_search(self, keywords: List[str], top_k: int = 5) -> List[SearchResult]:
        """Fast keyword-based search as a fallback."""
        conn = sqlite3.connect(str(self.db_path))
        results = []
        seen_ids = set()

        for kw in keywords:
            rows = conn.execute("""
                SELECT id, manual_name, section_number, section_title,
                       content, page_start, element_tags, keywords
                FROM sections
                WHERE content LIKE ? OR section_title LIKE ? OR keywords LIKE ?
                LIMIT ?
            """, (f"%{kw}%", f"%{kw}%", f"%{kw}%", top_k * 2)).fetchall()

            for row in rows:
                sid = row[0]
                if sid in seen_ids:
                    continue
                seen_ids.add(sid)

                manual_name = row[1]
                sec_num     = row[2]
                title       = row[3]
                content     = row[4]
                page_start  = row[5]
                elem_tags   = json.loads(row[6]) if row[6] else []
                kws         = json.loads(row[7]) if row[7] else []

                citation = _format_citation(manual_name, sec_num, title, page_start)
                results.append(SearchResult(
                    manual_name=manual_name,
                    section_number=sec_num,
                    section_title=title,
                    content=content[:1000],
                    page_start=page_start,
                    element_tags=elem_tags,
                    keywords=kws,
                    score=1.0,
                    citation=citation
                ))

                if len(results) >= top_k:
                    break
            if len(results) >= top_k:
                break

        conn.close()
        return results

    def get_section_count(self) -> int:
        conn = sqlite3.connect(str(self.db_path))
        count = conn.execute("SELECT COUNT(*) FROM sections").fetchone()[0]
        conn.close()
        return count

    def get_manual_list(self) -> List[str]:
        conn = sqlite3.connect(str(self.db_path))
        rows = conn.execute(
            "SELECT DISTINCT manual_name FROM sections ORDER BY manual_name"
        ).fetchall()
        conn.close()
        return [r[0] for r in rows]

    def stats(self):
        """Print database statistics."""
        count = self.get_section_count()
        manuals = self.get_manual_list()
        print(f"\nVector Store Statistics")
        print(f"{'─'*40}")
        print(f"Total sections : {count:,}")
        print(f"Manuals loaded : {len(manuals)}")
        for m in manuals:
            conn = sqlite3.connect(str(self.db_path))
            n = conn.execute(
                "SELECT COUNT(*) FROM sections WHERE manual_name=?", (m,)
            ).fetchone()[0]
            conn.close()
            print(f"  • {m}: {n} sections")
        print(f"Index built    : {self.index_path.exists()}")
        if self.tfidf_matrix is not None:
            print(f"Index size     : {self.tfidf_matrix.shape}")


def _format_citation(manual_name: str, section_number: str,
                     section_title: str, page: int) -> str:
    """Format a standard citation string."""
    parts = []
    # Clean up manual name
    name = manual_name.replace("_", " ").replace("-", " ").title()
    parts.append(name)
    if section_number:
        parts.append(f"Section {section_number}")
    if section_title:
        parts.append(section_title)
    if page:
        parts.append(f"p.{page}")
    return " — ".join(parts)


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Vector store operations")
    sub = p.add_subparsers(dest="cmd")

    # Build from parsed manuals
    pb = sub.add_parser("build", help="Build vector store from parsed manual sections")
    pb.add_argument("--sections-dir", default="./manuals/processed")
    pb.add_argument("--store-path",   default="./vector_store")

    # Search
    ps = sub.add_parser("search", help="Search the vector store")
    ps.add_argument("--query",      required=True)
    ps.add_argument("--store-path", default="./vector_store")
    ps.add_argument("--top-k",      type=int, default=3)
    ps.add_argument("--element",    default="")

    # Stats
    pst = sub.add_parser("stats", help="Show database statistics")
    pst.add_argument("--store-path", default="./vector_store")

    args = p.parse_args()

    if args.cmd == "build":
        store = TFIDFVectorStore(args.store_path)
        sections_dir = Path(args.sections_dir)
        all_sections = []

        # Load all section JSON files
        for jfile in sorted(sections_dir.glob("*.json")):
            if jfile.name == "all_sections.json":
                continue
            try:
                with open(jfile) as f:
                    secs = json.load(f)
                all_sections.extend(secs)
                log.info(f"Loaded {len(secs)} sections from {jfile.name}")
            except Exception as e:
                log.warning(f"Could not load {jfile.name}: {e}")

        # Also try combined file
        combined = sections_dir / "all_sections.json"
        if combined.exists() and not all_sections:
            with open(combined) as f:
                all_sections = json.load(f)

        log.info(f"Total sections to index: {len(all_sections)}")
        store.add_sections(all_sections, rebuild_index=True)
        store.stats()

    elif args.cmd == "search":
        store = TFIDFVectorStore(args.store_path)
        results = store.search(args.query, top_k=args.top_k,
                               element_filter=args.element or None)
        print(f"\nResults for: '{args.query}'\n{'─'*60}")
        for i, r in enumerate(results, 1):
            print(f"\n[{i}] Score: {r.score:.3f}")
            print(f"    {r.citation}")
            print(f"    Elements: {', '.join(r.element_tags) or 'general'}")
            print(f"    Preview: {r.content[:200]}...")

    elif args.cmd == "stats":
        store = TFIDFVectorStore(args.store_path)
        store.stats()

    else:
        p.print_help()
