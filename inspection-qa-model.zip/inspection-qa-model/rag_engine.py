"""
rag_engine.py — Retrieval-Augmented Generation Engine
Retrieves relevant manual sections at inference time and injects them
as guardrails into the model prompt. The model must align its output
with the retrieved manual guidance.

This is what makes the model cite sources and catch edge cases.
"""

import re
import json
import logging
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

log = logging.getLogger(__name__)

from vector_store import TFIDFVectorStore, SearchResult


# ──────────────────────────────────────────────
# TxDOT domain knowledge
# ──────────────────────────────────────────────

# Maps inspection findings to relevant search queries
FINDING_QUERIES = {
    "deck":          ["deck condition rating", "deck spalling delamination", "deck inspection criteria"],
    "superstructure":["superstructure rating", "steel beam condition", "girder inspection"],
    "substructure":  ["substructure pier abutment rating", "concrete deterioration substructure"],
    "bearing":       ["bearing inspection criteria", "bearing condition rating", "bearing seat"],
    "joint":         ["expansion joint inspection", "joint seal condition"],
    "scour":         ["scour evaluation procedure", "scour critical bridge", "channel inspection"],
    "railing":       ["railing inspection", "bridge rail condition"],
    "spalling":      ["spalling evaluation criteria", "concrete spalling rating"],
    "cracking":      ["crack inspection criteria", "crack severity rating"],
    "corrosion":     ["corrosion section loss", "steel corrosion rating"],
    "delamination":  ["delamination inspection", "concrete delamination rating"],
    "efflorescence": ["efflorescence concrete inspection"],
    "settlement":    ["settlement abutment inspection", "foundation settlement"],
    "paint":         ["paint condition rating", "coating inspection"],
}

# NBI condition rating descriptions per TxDOT
NBI_RATINGS = {
    9: "Excellent condition",
    8: "Very good condition — no problems noted",
    7: "Good condition — some minor problems",
    6: "Satisfactory condition — structural elements show some minor deterioration",
    5: "Fair condition — all primary structural elements are sound but may have minor section loss, cracking, spalling, or scour",
    4: "Poor condition — advanced section loss, deterioration, spalling or scour",
    3: "Serious condition — loss of section, deterioration, spalling or scour have seriously affected primary structural components",
    2: "Critical condition — advanced deterioration of primary structural elements",
    1: "Imminent failure condition",
    0: "Failed condition — out of service",
}

# Keywords that trigger guardrail injection
GUARDRAIL_TRIGGERS = [
    "critical", "serious", "poor", "imminent", "failure",
    "scour", "fracture", "load posting", "closure", "emergency",
    "section loss", "undermining", "collision", "fire damage"
]


# ──────────────────────────────────────────────
# RAG context builder
# ──────────────────────────────────────────────

@dataclass
class RAGContext:
    """Retrieved context to inject into the model prompt."""
    sections:    List[SearchResult]
    guardrails:  List[str]   # specific rules the model must follow
    citations:   List[str]   # formatted citations
    warnings:    List[str]   # edge case warnings


class RAGEngine:
    """
    Retrieval-Augmented Generation engine.
    Searches the manual database and builds guardrail context
    for each inference request.
    """

    def __init__(self, store_path: str = "./vector_store",
                 max_sections: int = 3,
                 max_context_chars: int = 2000):
        self.store = TFIDFVectorStore(store_path)
        self.max_sections = max_sections
        self.max_context_chars = max_context_chars
        log.info(f"RAG engine loaded — {self.store.get_section_count()} manual sections available")

    def _extract_elements(self, text: str) -> List[str]:
        """Extract bridge elements mentioned in text."""
        text_lower = text.lower()
        elements = [
            "deck", "superstructure", "substructure", "bearing",
            "joint", "scour", "railing", "pier", "abutment",
            "culvert", "channel", "approach"
        ]
        return [e for e in elements if e in text_lower]

    def _extract_rating(self, text: str) -> Optional[int]:
        """Extract NBI condition rating from text."""
        patterns = [
            r'rated?\s+(\d)',
            r'rating[:\s]+(\d)',
            r'condition[:\s]+(\d)',
            r'\b([0-9])\s*[-–]\s*(?:poor|fair|good|satisfactory|serious|critical|excellent)',
        ]
        for pat in patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                try:
                    return int(m.group(1))
                except:
                    pass
        return None

    def _check_guardrail_triggers(self, text: str) -> List[str]:
        """Check if text contains keywords requiring guardrail injection."""
        text_lower = text.lower()
        return [t for t in GUARDRAIL_TRIGGERS if t in text_lower]

    def retrieve(self, query: str, finding_text: str = "",
                 element: str = "") -> RAGContext:
        """
        Retrieve relevant manual sections for a given query/finding.

        Args:
            query: The main search query (e.g. "spalling on pier cap")
            finding_text: Full text of the finding for trigger detection
            element: Specific bridge element to filter by

        Returns:
            RAGContext with retrieved sections and guardrails
        """
        # Build search queries
        search_queries = [query]

        # Add element-specific queries
        elements = self._extract_elements(finding_text or query)
        if element:
            elements = [element] + elements
        for elem in elements[:2]:
            if elem in FINDING_QUERIES:
                search_queries.extend(FINDING_QUERIES[elem][:2])

        # Search for relevant sections
        all_results = []
        seen_sections = set()

        for q in search_queries[:4]:
            results = self.store.search(
                q, top_k=self.max_sections,
                element_filter=element if element else None
            )
            for r in results:
                key = (r.manual_name, r.section_number)
                if key not in seen_sections and r.score > 0.05:
                    seen_sections.add(key)
                    all_results.append(r)

        # Sort by relevance score
        all_results.sort(key=lambda r: r.score, reverse=True)
        top_sections = all_results[:self.max_sections]

        # Build guardrails
        guardrails = []
        warnings = []
        triggers = self._check_guardrail_triggers(finding_text or query)

        if triggers:
            warnings.append(
                f"⚠ Edge case detected: {', '.join(triggers)}. "
                "Manual guidance has been retrieved — response must align with manual procedures."
            )

        # Add rating-specific guardrail
        rating = self._extract_rating(finding_text or query)
        if rating is not None and rating in NBI_RATINGS:
            guardrails.append(
                f"NBI Rating {rating} = {NBI_RATINGS[rating]}. "
                "Verify this rating is consistent with described conditions per TxDOT standards."
            )
            if rating <= 3:
                guardrails.append(
                    f"CRITICAL: Rating {rating} requires immediate notification to TxDOT engineer "
                    "and may require load posting or bridge closure per TxDOT policy."
                )
            elif rating == 4:
                guardrails.append(
                    "Rating 4-Poor requires documentation of a maintenance plan "
                    "and follow-up inspection schedule."
                )

        # Add section-specific guardrails from retrieved content
        for section in top_sections:
            if any(t in section.content.lower() for t in ["shall", "must", "required", "mandatory"]):
                # Extract key requirements
                req_sentences = [
                    sent.strip() for sent in section.content.split('.')
                    if any(w in sent.lower() for w in ["shall", "must", "required", "mandatory"])
                    and len(sent.strip()) > 20
                ][:2]
                for req in req_sentences:
                    guardrails.append(f"Per {section.citation}: {req}.")

        citations = [s.citation for s in top_sections]

        return RAGContext(
            sections=top_sections,
            guardrails=guardrails,
            citations=citations,
            warnings=warnings
        )

    def build_prompt(self, task: str, document_text: str,
                     rag_context: RAGContext,
                     system_prompt: str = "") -> str:
        """
        Build the full prompt with retrieved manual context injected as guardrails.
        """
        # Task descriptions
        task_prompts = {
            "issues": "Identify ALL issues, deficiencies, and problems in this bridge inspection document. For each finding, state the element, describe the problem, rate severity, and cite the relevant manual section.",
            "summary": "Summarize the key findings in this bridge inspection document. Include structure ID, inspection date, condition ratings for each element, and any items requiring follow-up.",
            "ratings": "Review all condition ratings in this document. For each element, verify the rating is consistent with the described conditions per TxDOT standards and flag any discrepancies.",
            "missing": "Identify all missing, incomplete, or blank required fields in this inspection document that must be completed per TxDOT requirements.",
            "recs": "Based on the findings, provide specific repair and maintenance recommendations for each deficiency, prioritized by urgency and citing the relevant TxDOT manual section.",
            "analyze": "Provide a comprehensive analysis of this bridge inspection document.",
        }

        task_instruction = task_prompts.get(task, task_prompts["analyze"])

        # Build manual context section
        manual_context = ""
        if rag_context.sections:
            manual_context = "\n\n=== RELEVANT MANUAL GUIDANCE ===\n"
            manual_context += "(Use these sections as guardrails — your response must align with this guidance)\n\n"

            total_chars = 0
            for i, section in enumerate(rag_context.sections, 1):
                content_preview = section.content[:600]
                if total_chars + len(content_preview) > self.max_context_chars:
                    content_preview = content_preview[:self.max_context_chars - total_chars]
                entry = (
                    f"[Manual Reference {i}]\n"
                    f"Source: {section.citation}\n"
                    f"Content: {content_preview}\n"
                )
                manual_context += entry + "\n"
                total_chars += len(content_preview)
                if total_chars >= self.max_context_chars:
                    break

        # Build guardrails section
        guardrail_text = ""
        if rag_context.guardrails:
            guardrail_text = "\n\n=== REQUIRED GUARDRAILS ===\n"
            guardrail_text += "(Your response MUST comply with these requirements)\n"
            for g in rag_context.guardrails:
                guardrail_text += f"• {g}\n"

        # Build warnings section
        warning_text = ""
        if rag_context.warnings:
            warning_text = "\n\n=== EDGE CASE WARNINGS ===\n"
            for w in rag_context.warnings:
                warning_text += f"{w}\n"

        # Final prompt
        base_sys = system_prompt or (
            "You are a TxDOT bridge inspection expert. Analyze inspection documents "
            "carefully using standard TxDOT terminology. Always cite manual sections "
            "when making findings. Flag any safety concerns immediately."
        )

        prompt = (
            f"{base_sys}"
            f"{manual_context}"
            f"{guardrail_text}"
            f"{warning_text}"
            f"\n\n=== TASK ===\n{task_instruction}"
            f"\n\n=== INSPECTION DOCUMENT ===\n{document_text}"
            f"\n\n=== YOUR ANALYSIS ===\n"
            f"(Cite manual sections as: [Source: Manual Name, Section X.X.X, p.N])\n"
        )

        return prompt

    def format_output_with_citations(self, raw_output: str,
                                      rag_context: RAGContext) -> str:
        """
        Post-process model output to ensure citations are properly formatted
        and add a references section at the end.
        """
        output = raw_output.strip()

        # Add references section if citations exist
        if rag_context.citations:
            output += "\n\n─────────────────────────────────\n"
            output += "MANUAL REFERENCES\n"
            for i, citation in enumerate(rag_context.citations, 1):
                output += f"[{i}] {citation}\n"

        # Add guardrail compliance note
        if rag_context.guardrails:
            output += "\n─────────────────────────────────\n"
            output += "REGULATORY REQUIREMENTS\n"
            for g in rag_context.guardrails[:3]:
                output += f"• {g}\n"

        return output


# ──────────────────────────────────────────────
# Guardrail checker
# ──────────────────────────────────────────────

class GuardrailChecker:
    """
    Checks model output against manual guidance.
    Flags contradictions or missing required elements.
    """

    def __init__(self, store: TFIDFVectorStore):
        self.store = store

    def check_rating_consistency(self, element: str, rating: int,
                                  description: str) -> List[str]:
        """
        Check if a condition rating is consistent with the description
        and manual guidance.
        """
        issues = []

        # Search for rating criteria
        query = f"{element} condition rating {rating} criteria"
        results = self.store.search(query, top_k=2)

        # Basic consistency checks
        critical_words = ["spalling", "section loss", "delamination", "cracking", "corrosion"]
        desc_lower = description.lower()
        has_defects = any(w in desc_lower for w in critical_words)

        if rating >= 7 and has_defects:
            issues.append(
                f"⚠ RATING INCONSISTENCY: Rating {rating} (Good/Very Good) "
                f"but description mentions defects. Verify per TxDOT standards."
            )
        if rating <= 3 and "no" in desc_lower and "defect" not in desc_lower:
            issues.append(
                f"⚠ RATING INCONSISTENCY: Rating {rating} (Serious/Critical) "
                f"but description doesn't mention significant defects."
            )

        return issues

    def check_required_fields(self, document_text: str) -> List[str]:
        """Check for commonly required TxDOT inspection fields."""
        missing = []
        required_fields = [
            ("Structure ID", ["structure id", "str id", "bridge id"]),
            ("Inspection date", ["inspection date", "date of inspection", "insp date"]),
            ("Inspector name", ["inspector", "inspected by"]),
            ("Deck rating", ["deck", "deck rating", "item 58"]),
            ("Superstructure rating", ["superstructure", "super rating", "item 59"]),
            ("Substructure rating", ["substructure", "sub rating", "item 60"]),
            ("Channel rating", ["channel", "channel rating", "item 61"]),
        ]

        doc_lower = document_text.lower()
        for field_name, patterns in required_fields:
            if not any(p in doc_lower for p in patterns):
                missing.append(f"Missing or not found: {field_name}")

        return missing


# ──────────────────────────────────────────────
# CLI test
# ──────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Test RAG engine")
    p.add_argument("--store-path", default="./vector_store")
    p.add_argument("--query",      default="spalling on pier cap rated 4 poor")
    p.add_argument("--element",    default="substructure")
    args = p.parse_args()

    engine = RAGEngine(args.store_path)
    ctx = engine.retrieve(args.query, element=args.element)

    print(f"\nQuery: '{args.query}'")
    print(f"Retrieved {len(ctx.sections)} manual sections\n")

    for i, s in enumerate(ctx.sections, 1):
        print(f"[{i}] {s.citation} (score={s.score:.3f})")
        print(f"     {s.content[:200]}...\n")

    print("Guardrails:")
    for g in ctx.guardrails:
        print(f"  • {g}")

    print("\nWarnings:")
    for w in ctx.warnings:
        print(f"  {w}")
