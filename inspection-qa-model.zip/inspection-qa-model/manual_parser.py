"""
manual_parser.py — TxDOT Manual Parser (Python 3.12 compatible)
Parses inspection manuals into structured sections with metadata.
Uses pypdf instead of PyMuPDF to avoid Python 3.12 inspect conflicts.
Supports PDF, PPTX, and XLSX formats.

Install: pip install pypdf python-pptx openpyxl --break-system-packages
"""

import os
import re
import json
import logging
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Optional, Dict

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

try:
    from pypdf import PdfReader
    HAS_PDF = True
except ImportError:
    HAS_PDF = False

try:
    from pptx import Presentation
    HAS_PPTX = True
except ImportError:
    HAS_PPTX = False

try:
    import openpyxl
    HAS_XLSX = True
except ImportError:
    HAS_XLSX = False


# ──────────────────────────────────────────────
# Data structure
# ──────────────────────────────────────────────

@dataclass
class ManualSection:
    manual_name:    str
    section_number: str
    section_title:  str
    content:        str
    page_start:     int
    page_end:       int
    level:          int
    keywords:       List[str]
    tables:         List[Dict]
    parent_section: str
    element_tags:   List[str]


# ──────────────────────────────────────────────
# TxDOT domain knowledge
# ──────────────────────────────────────────────

TXDOT_ELEMENTS = [
    "deck", "superstructure", "substructure", "culvert",
    "channel", "bearing", "joint", "railing", "approach",
    "pier", "abutment", "foundation", "scour", "paint",
    "steel", "concrete", "timber", "prestressed"
]

CONDITION_KEYWORDS = [
    "excellent", "very good", "good", "satisfactory", "fair",
    "poor", "serious", "critical", "imminent failure",
    "rating", "nbi", "condition", "deficiency", "defect",
    "spalling", "delamination", "cracking", "corrosion",
    "section loss", "efflorescence", "scour", "settlement",
    "undermining", "collision", "deterioration", "repair",
    "maintenance", "inspection", "engineer", "load posting",
    "snbi", "load rating", "fracture critical", "underwater"
]

SECTION_PATTERNS = [
    re.compile(r'^(\d+\.\d+\.\d+\.\d+)\s+(.+)'),
    re.compile(r'^(\d+\.\d+\.\d+)\s+(.+)'),
    re.compile(r'^(\d+\.\d+)\s+(.+)'),
    re.compile(r'^(\d+)\.\s+(.+)'),
    re.compile(r'^(Chapter\s+\d+)\s*[:\-]?\s*(.+)', re.IGNORECASE),
    re.compile(r'^(Appendix\s+[A-Z])\s*[:\-]?\s*(.+)', re.IGNORECASE),
    re.compile(r'^(B\.[A-Z]{1,4}\.\d{2})\s*[:\-]?\s*(.+)'),  # SNBI field codes
]


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def extract_keywords(text: str) -> List[str]:
    text_lower = text.lower()
    return list(set(kw for kw in CONDITION_KEYWORDS if kw in text_lower))


def extract_element_tags(text: str) -> List[str]:
    text_lower = text.lower()
    return [elem for elem in TXDOT_ELEMENTS if elem in text_lower]


def detect_heading(text: str, line_num: int) -> Optional[tuple]:
    """Returns (section_number, title, level) if heading, else None."""
    text = text.strip()
    if not text or len(text) > 200:
        return None
    for i, pattern in enumerate(SECTION_PATTERNS):
        m = pattern.match(text)
        if m:
            sec_num = m.group(1).strip()
            title   = m.group(2).strip()
            depth   = sec_num.count('.') + 1
            if any(x in sec_num for x in ['Chapter', 'Appendix']):
                depth = 1
            return (sec_num, title, min(depth, 4))
    # Short lines near the top are likely headings
    if line_num < 3 and len(text) < 100 and text[0].isupper():
        return ("", text, 1)
    return None


def lines_to_sections(lines: List[str], manual_name: str,
                       page_offset: int = 0) -> List[ManualSection]:
    """Convert a list of text lines into ManualSection objects."""
    sections: List[ManualSection] = []
    current_section = None
    current_lines   = []
    current_page    = page_offset

    for line_num, line in enumerate(lines):
        text = line.strip()
        if not text:
            if current_lines:
                current_lines.append("")
            continue

        heading = detect_heading(text, line_num)

        if heading:
            # Save previous section
            if current_section and current_lines:
                content = "\n".join(current_lines).strip()
                if len(content) > 30:
                    current_section.content       = content
                    current_section.keywords      = extract_keywords(content)
                    current_section.element_tags  = extract_element_tags(
                        current_section.section_title + " " + content
                    )
                    sections.append(current_section)

            sec_num, title, level = heading
            parent = '.'.join(sec_num.split('.')[:-1]) if '.' in sec_num else ""
            current_section = ManualSection(
                manual_name=manual_name,
                section_number=sec_num,
                section_title=title,
                content="",
                page_start=current_page,
                page_end=current_page,
                level=level,
                keywords=[],
                tables=[],
                parent_section=parent,
                element_tags=[]
            )
            current_lines = [text]
        else:
            if current_section is None:
                current_section = ManualSection(
                    manual_name=manual_name,
                    section_number="0",
                    section_title="Introduction",
                    content="",
                    page_start=page_offset,
                    page_end=page_offset,
                    level=1,
                    keywords=[],
                    tables=[],
                    parent_section="",
                    element_tags=[]
                )
            current_lines.append(text)

    # Save final section
    if current_section and current_lines:
        content = "\n".join(current_lines).strip()
        if len(content) > 30:
            current_section.content      = content
            current_section.keywords     = extract_keywords(content)
            current_section.element_tags = extract_element_tags(
                current_section.section_title + " " + content
            )
            sections.append(current_section)

    return sections


# ──────────────────────────────────────────────
# Format-specific parsers
# ──────────────────────────────────────────────

def parse_pdf_manual(pdf_path: str, manual_name: str) -> List[ManualSection]:
    if not HAS_PDF:
        raise ImportError("pypdf required: pip install pypdf --break-system-packages")
    reader   = PdfReader(str(pdf_path))
    all_lines = []
    for page_num, page in enumerate(reader.pages):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        for line in text.split("\n"):
            all_lines.append(line)
        all_lines.append("")  # page separator
    sections = lines_to_sections(all_lines, manual_name)
    log.info(f"PDF: {Path(pdf_path).name} — {len(reader.pages)} pages, "
             f"{len(sections)} sections")
    return sections


def parse_pptx_manual(pptx_path: str, manual_name: str) -> List[ManualSection]:
    if not HAS_PPTX:
        raise ImportError("python-pptx required: pip install python-pptx --break-system-packages")
    prs = Presentation(str(pptx_path))
    sections = []
    for slide_num, slide in enumerate(prs.slides):
        slide_lines = []
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                slide_lines.extend(shape.text.strip().split("\n"))
            if shape.has_table:
                for row in shape.table.rows:
                    row_text = " | ".join(
                        c.text.strip() for c in row.cells if c.text.strip()
                    )
                    if row_text:
                        slide_lines.append(row_text)
        if slide_lines:
            slide_sections = lines_to_sections(slide_lines, manual_name, slide_num)
            if not slide_sections:
                # Treat entire slide as one section if no headings detected
                content = "\n".join(slide_lines).strip()
                if len(content) > 30:
                    sections.append(ManualSection(
                        manual_name=manual_name,
                        section_number=str(slide_num + 1),
                        section_title=slide_lines[0][:80] if slide_lines else f"Slide {slide_num+1}",
                        content=content,
                        page_start=slide_num + 1,
                        page_end=slide_num + 1,
                        level=2,
                        keywords=extract_keywords(content),
                        tables=[],
                        parent_section="",
                        element_tags=extract_element_tags(content)
                    ))
            else:
                sections.extend(slide_sections)
    log.info(f"PPTX: {Path(pptx_path).name} — {len(prs.slides)} slides, "
             f"{len(sections)} sections")
    return sections


def parse_xlsx_manual(xlsx_path: str, manual_name: str) -> List[ManualSection]:
    if not HAS_XLSX:
        raise ImportError("openpyxl required: pip install openpyxl --break-system-packages")
    wb = openpyxl.load_workbook(str(xlsx_path), read_only=True, data_only=True)
    sections = []
    for sheet in wb.worksheets:
        rows = []
        for row in sheet.iter_rows(values_only=True):
            row_vals = [str(c) if c is not None else "" for c in row]
            row_text = " | ".join(v for v in row_vals if v.strip())
            if row_text.strip():
                rows.append(row_text)
        if rows:
            content = "\n".join(rows)
            if len(content) > 30:
                sections.append(ManualSection(
                    manual_name=manual_name,
                    section_number=sheet.title,
                    section_title=sheet.title,
                    content=content,
                    page_start=1,
                    page_end=1,
                    level=1,
                    keywords=extract_keywords(content),
                    tables=[],
                    parent_section="",
                    element_tags=extract_element_tags(content)
                ))
    wb.close()
    log.info(f"XLSX: {Path(xlsx_path).name} — {len(sections)} sheets parsed")
    return sections


# ──────────────────────────────────────────────
# Main batch parser
# ──────────────────────────────────────────────

def parse_manual(file_path: str, manual_name: str = "") -> List[ManualSection]:
    path = Path(file_path)
    if not manual_name:
        manual_name = path.stem
    ext = path.suffix.lower()
    log.info(f"Parsing manual: {path.name}")
    if ext == ".pdf":
        return parse_pdf_manual(str(path), manual_name)
    elif ext in (".pptx", ".ppt"):
        return parse_pptx_manual(str(path), manual_name)
    elif ext in (".xlsx", ".xls"):
        return parse_xlsx_manual(str(path), manual_name)
    else:
        log.warning(f"Unsupported format: {ext} — skipping {path.name}")
        return []


def save_sections(sections: List[ManualSection], output_path: str):
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump([asdict(s) for s in sections], f, indent=2)
    log.info(f"Saved {len(sections)} sections -> {output_path}")


def batch_parse_manuals(manual_dir: str, output_dir: str) -> List[dict]:
    manual_dir = Path(manual_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    extensions = (".pdf", ".pptx", ".ppt", ".xlsx", ".xls")
    files = sorted(
        f for f in manual_dir.rglob("*")
        if f.suffix.lower() in extensions and f.is_file()
    )
    log.info(f"Found {len(files)} manual files in {manual_dir}")

    all_sections = []
    for file_path in files:
        out = output_dir / (file_path.stem + "_sections.json")
        if out.exists():
            log.info(f"Skipping (already parsed): {file_path.name}")
            with open(out) as f:
                all_sections.extend(json.load(f))
            continue
        try:
            sections = parse_manual(str(file_path))
            if sections:
                save_sections(sections, str(out))
                all_sections.extend([asdict(s) for s in sections])
            else:
                log.warning(f"No sections extracted: {file_path.name}")
        except Exception as e:
            log.error(f"Failed {file_path.name}: {e}")

    # Save combined index
    combined = output_dir / "all_sections.json"
    with open(combined, "w") as f:
        json.dump(all_sections, f, indent=2)
    log.info(f"Total: {len(all_sections)} sections -> {combined}")
    return all_sections


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Parse TxDOT manuals into sections")
    p.add_argument("--manual-dir",  default="./data/raw_pdfs/manuals")
    p.add_argument("--output-dir",  default="./manuals/processed")
    p.add_argument("--single",      default="")
    args = p.parse_args()

    if args.single:
        sections = parse_manual(args.single)
        out = args.single.rsplit(".", 1)[0] + "_sections.json"
        save_sections(sections, out)
        print(f"\nParsed {len(sections)} sections:")
        for s in sections[:10]:
            print(f"  [{s.section_number}] {s.section_title} "
                  f"(p.{s.page_start}) — {len(s.content)} chars")
    else:
        batch_parse_manuals(args.manual_dir, args.output_dir)
