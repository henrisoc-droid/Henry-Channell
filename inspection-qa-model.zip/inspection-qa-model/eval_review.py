"""
eval_review.py

Loads checkpoints_v4/layout_final.pt and runs the QA-checker model on a
handful of examples from data/pairs/review_sft_corpus.jsonl so you can
read the generated completions against the ground-truth QA flags.

Usage:
    python eval_review.py --checkpoint checkpoints_v4\\layout_final.pt --tokenizer tokenizer\\layout_bpe.model --corpus data\\pairs\\review_sft_corpus.jsonl --n 10

Notes:
- Uses the SAME random_split(seed=42) logic as train_layout.py's SFT path
  so the "val" examples shown here are the actual held-out set the model
  was NOT trained on (n_val = min(50, max(5, 10% of corpus))).
- Calls LayoutLM.generate() with only token_ids -- no layout tensors --
  matching how SFTInstructionDataset trained on this corpus (plain
  tokenizer.encode(prompt) / tokenizer.encode(completion), no spatial
  metadata).
"""

import argparse
import json
import random
import sys
from pathlib import Path

import torch

from layout_model import LayoutLM, LAYOUT_CONFIGS
from layout_tokenizer import LayoutBPETokenizer


def load_corpus(corpus_path: str):
    examples = []
    skipped = 0
    with open(corpus_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                skipped += 1
                continue
            prompt = obj.get("prompt", "")
            completion = obj.get("completion", "")
            if not prompt or not completion:
                skipped += 1
                continue
            examples.append(obj)
    if skipped:
        print(f"[eval] skipped {skipped} malformed/empty lines while loading corpus")
    return examples


def get_val_split(examples, seed: int = 42):
    """Mirror train_layout.py: n_val = min(50, max(5, 10% of len))."""
    n = len(examples)
    n_val = min(50, max(5, int(0.10 * n)))
    n_train = n - n_val

    g = torch.Generator().manual_seed(seed)
    perm = torch.randperm(n, generator=g).tolist()

    train_idx = perm[:n_train]
    val_idx = perm[n_train:]

    train_ex = [examples[i] for i in train_idx]
    val_ex = [examples[i] for i in val_idx]
    return train_ex, val_ex


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--tokenizer", required=True)
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--config", default="small", choices=list(LAYOUT_CONFIGS.keys()))
    ap.add_argument("--n", type=int, default=10, help="number of val examples to evaluate")
    ap.add_argument("--max-new-tokens", type=int, default=256)
    ap.add_argument("--temperature", type=float, default=0.3)
    ap.add_argument("--top-k", type=int, default=40)
    ap.add_argument("--top-p", type=float, default=0.9)
    ap.add_argument("--repetition-penalty", type=float, default=1.3)
    ap.add_argument("--no-repeat-ngram-size", type=int, default=4)
    ap.add_argument("--stop-token", type=int, default=3)
    ap.add_argument("--seed", type=int, default=42, help="must match training seed for the same val split")
    ap.add_argument("--all-val", action="store_true", help="evaluate the full val set instead of --n examples")
    ap.add_argument("--out", default=None, help="optional path to write full results as JSON")
    args = ap.parse_args()

    device = (
        torch.device("cuda") if torch.cuda.is_available()
        else torch.device("mps") if torch.backends.mps.is_available()
        else torch.device("cpu")
    )
    print(f"[eval] device: {device}")

    print(f"[eval] loading tokenizer: {args.tokenizer}")
    tokenizer = LayoutBPETokenizer(args.tokenizer)

    print(f"[eval] loading corpus: {args.corpus}")
    examples = load_corpus(args.corpus)
    print(f"[eval] {len(examples)} usable examples")

    train_ex, val_ex = get_val_split(examples, seed=args.seed)
    print(f"[eval] split: train={len(train_ex)} val={len(val_ex)}")

    if not args.all_val:
        random.seed(args.seed)
        sample = val_ex if len(val_ex) <= args.n else random.sample(val_ex, args.n)
    else:
        sample = val_ex

    print(f"[eval] evaluating {len(sample)} val examples")

    cfg = LAYOUT_CONFIGS[args.config]
    cfg.vocab_size = tokenizer.vocab_size
    model = LayoutLM(cfg).to(device)

    print(f"[eval] loading checkpoint: {args.checkpoint}")
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt["model"])
    model.eval()
    print(f"[eval] checkpoint step={ckpt.get('step')} val_loss={ckpt.get('val_loss')}")

    results = []
    for i, ex in enumerate(sample):
        pair_id = ex.get("pair_id", f"idx{i}")
        prompt = ex["prompt"]
        gt_completion = ex["completion"]

        prompt_ids = tokenizer.encode(prompt)
        token_ids = torch.tensor([prompt_ids], dtype=torch.long, device=device)

        with torch.no_grad():
            out_ids = model.generate(
                token_ids,
                max_new_tokens=args.max_new_tokens,
                temperature=args.temperature,
                top_k=args.top_k,
                top_p=args.top_p,
                repetition_penalty=args.repetition_penalty,
                no_repeat_ngram_size=args.no_repeat_ngram_size,
                stop_token=args.stop_token,
            )

        gen_ids = out_ids[0, token_ids.shape[1]:].tolist()
        gen_text = tokenizer.decode(gen_ids)

        print("=" * 100)
        print(f"[{i+1}/{len(sample)}] pair_id: {pair_id}")
        print("-" * 100)
        print("GROUND TRUTH COMPLETION:")
        print(gt_completion)
        print("-" * 100)
        print("MODEL GENERATED COMPLETION:")
        print(gen_text)
        print()

        results.append({
            "pair_id": pair_id,
            "ground_truth": gt_completion,
            "generated": gen_text,
        })

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        print(f"[eval] wrote {len(results)} results -> {args.out}")


if __name__ == "__main__":
    main()
