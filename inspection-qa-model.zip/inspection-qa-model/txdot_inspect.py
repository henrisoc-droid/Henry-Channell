"""
inspect.py — Main Inference Pipeline
Combines the layout model + RAG guardrails + PDF annotation writer.
This is the single entry point for analyzing inspection PDFs.

Usage:
  # Analyze a PDF with manual guardrails
  python inspect.py analyze \
      --input  report.pdf \
      --output report_ANNOTATED.pdf \
      --task   issues

  # Build the manual database (run once)
  python inspect.py build-db \
      --manual-dir ./manuals/raw

  # Test the RAG system
  python inspect.py test-rag \
      --query "spalling on deck rated 4"
"""

import os
import sys
import json
import logging
import argparse
from pathlib import Path
from typing import Optional

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# ──────────────────────────────────────────────
# LM Studio API client (uses your trained model)
# ──────────────────────────────────────────────

import urllib.request
import urllib.error

def call_lm_studio(prompt: str, model: str = "txdot-llm:2",
                   server: str = "http://localhost:1234",
                   max_tokens: int = 800,
                   temperature: float = 0.2) -> str:
    """
    Send a prompt to your model running in LM Studio.
    Falls back to a simple text response if not available.
    """
    import json as _json
    payload = _json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False
    }).encode("utf-8")

    req = urllib.request.Request(
        f"{server}/v1/chat/completions",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = _json.loads(resp.read().decode())
            return data["choices"][0]["message"]["content"]
    except urllib.error.URLError as e:
        raise ConnectionError(
            f"Cannot reach LM Studio at {server}. "
            "Make sure LM Studio is running with Local Server enabled."
        ) from e


# ──────────────────────────────────────────────
# Full pipeline
# ──────────────────────────────────────────────

def analyze_pdf(
    input_pdf:   str,
    output_pdf:  str,
    task:        str = "issues",
    store_path:  str = "./vector_store",
    lm_server:   str = "http://localhost:1234",
    lm_model:    str = "txdot-llm:2",
    max_pages:   int = 8,
    verbose:     bool = True
):
    """
    Full pipeline:
    1. Parse the input PDF
    2. Extract text for LM Studio
    3. Retrieve relevant manual sections (RAG)
    4. Build guardrail prompt
    5. Run model via LM Studio
    6. Write annotated PDF output
    """
    from pdf_parser import parse_pdf
    from rag_engine import RAGEngine
    from vector_store import TFIDFVectorStore

    # ── Step 1: Parse PDF ──
    log.info(f"Step 1/5: Parsing {input_pdf}")
    try:
        parsed = parse_pdf(input_pdf)
    except Exception as e:
        raise RuntimeError(f"Failed to parse PDF: {e}")

    # Extract plain text for LM Studio (limited to max_pages)
    doc_text_parts = []
    for page in parsed.pages[:max_pages]:
        page_text = f"\n--- Page {page.page_num + 1} ---\n"
        # Add text blocks sorted by reading order
        for block in sorted(page.blocks, key=lambda b: b.reading_order)[:50]:
            if block.text.strip():
                prefix = ""
                if block.block_type == "header":
                    prefix = "## "
                elif block.block_type == "label":
                    prefix = "FIELD: "
                page_text += prefix + block.text.strip() + "\n"
        # Add table summaries
        for table in page.tables:
            page_text += "\nTABLE:\n"
            rows = {}
            for cell in table.cells:  # cells are dicts (see pdf_parser.Table)
                rows.setdefault(cell["row"], []).append(cell.get("text", ""))
            for r_idx in sorted(rows.keys())[:8]:
                page_text += " | ".join(rows[r_idx]) + "\n"
        # Add form fields
        for field in page.form_fields:
            if field.field_name:
                page_text += f"FORM FIELD [{field.field_name}]: {field.field_value}\n"
        doc_text_parts.append(page_text)

    doc_text = "\n".join(doc_text_parts)

    if verbose:
        print(f"  Parsed {parsed.n_pages} pages, {len(doc_text)} chars extracted")

    # ── Step 2: RAG retrieval ──
    log.info("Step 2/5: Retrieving manual guidance")
    rag_context = None

    if Path(store_path).exists() and (Path(store_path) / "manual_store.db").exists():
        try:
            engine = RAGEngine(store_path)
            rag_context = engine.retrieve(
                query=f"bridge inspection {task} {parsed.filename}",
                finding_text=doc_text[:500]
            )
            if verbose:
                print(f"  Retrieved {len(rag_context.sections)} manual sections")
                for s in rag_context.sections:
                    print(f"    → {s.citation} (score={s.score:.3f})")
        except Exception as e:
            log.warning(f"RAG retrieval failed: {e} — proceeding without manual context")
    else:
        log.info("No vector store found — proceeding without manual context")
        log.info("Run: python inspect.py build-db --manual-dir ./manuals/raw")

    # ── Step 3: Build prompt ──
    log.info("Step 3/5: Building prompt")

    if rag_context and rag_context.sections:
        engine_obj = RAGEngine(store_path)
        prompt = engine_obj.build_prompt(task, doc_text, rag_context)
    else:
        # Fallback prompt without RAG
        task_instructions = {
            "issues":  "Identify ALL issues, deficiencies, and problems. For each: state the element, describe the problem, and rate severity as Critical/Warning/Minor.",
            "summary": "Summarize key findings: structure ID, inspection date, element ratings, items requiring follow-up.",
            "ratings": "Review all condition ratings. Flag any that don't match the described conditions.",
            "missing": "Identify all missing or incomplete required fields.",
            "recs":    "Provide specific repair recommendations for each deficiency, prioritized by urgency.",
            "analyze": "Provide a comprehensive analysis of this bridge inspection document.",
        }
        prompt = (
            f"You are a TxDOT bridge inspection expert.\n\n"
            f"TASK: {task_instructions.get(task, task_instructions['analyze'])}\n\n"
            f"DOCUMENT:\n{doc_text}\n\n"
            f"ANALYSIS:\n"
        )

    if verbose:
        print(f"  Prompt length: {len(prompt)} chars")

    # ── Step 4: Run model ──
    log.info("Step 4/5: Running model via LM Studio")
    try:
        model_output = call_lm_studio(
            prompt=prompt,
            model=lm_model,
            server=lm_server,
            max_tokens=800,
            temperature=0.2
        )
        if verbose:
            print(f"  Model output: {len(model_output)} chars")
    except ConnectionError as e:
        log.error(str(e))
        sys.exit(1)

    # Post-process with citations
    if rag_context:
        engine_obj = RAGEngine(store_path)
        model_output = engine_obj.format_output_with_citations(model_output, rag_context)

    if verbose:
        print("\n" + "="*60)
        print("MODEL OUTPUT:")
        print("="*60)
        print(model_output)
        print("="*60)

    # ── Step 5: Annotate PDF ──
    log.info(f"Step 5/5: Writing annotated PDF → {output_pdf}")
    try:
        import fitz
        from annotate_pdf import parse_model_output, add_annotations_to_pdf
        findings = parse_model_output(model_output)
        add_annotations_to_pdf(input_pdf, findings, output_pdf, model_output, task)
        print(f"\n✓ Annotated PDF saved: {output_pdf}")
        print(f"  Findings: {len(findings)} total")
    except ImportError:
        log.warning("annotate_pdf.py not found — saving text output only")
        txt_out = output_pdf.replace(".pdf", "_analysis.txt")
        with open(txt_out, "w", encoding="utf-8") as f:
            f.write(f"Analysis of: {input_pdf}\n")
            f.write(f"Task: {task}\n")
            f.write("="*60 + "\n")
            f.write(model_output)
        print(f"✓ Analysis saved: {txt_out}")
    except Exception as e:
        log.error(f"PDF annotation failed: {e}")
        txt_out = output_pdf.replace(".pdf", "_analysis.txt")
        with open(txt_out, "w", encoding="utf-8") as f:
            f.write(model_output)
        print(f"✓ Analysis saved as text: {txt_out}")

    return model_output


# ──────────────────────────────────────────────
# Database builder
# ──────────────────────────────────────────────

def build_database(manual_dir: str, store_path: str = "./vector_store"):
    """Parse all manuals and build the vector database."""
    from manual_parser import batch_parse_manuals
    from vector_store import TFIDFVectorStore

    manual_dir = Path(manual_dir)
    if not manual_dir.exists():
        print(f"Manual directory not found: {manual_dir}")
        print("Create it and add your TxDOT manual PDFs:")
        print(f"  mkdir {manual_dir}")
        return

    pdfs = list(manual_dir.rglob("*.pdf"))
    if not pdfs:
        print(f"No PDFs found in {manual_dir}")
        return

    print(f"Found {len(pdfs)} manual PDFs")

    # Step 1: Parse manuals
    processed_dir = Path("./manuals/processed")
    print("\nStep 1/2: Parsing manuals...")
    all_sections = batch_parse_manuals(str(manual_dir), str(processed_dir))

    # Step 2: Build vector store
    print(f"\nStep 2/2: Building vector database from {len(all_sections)} sections...")
    store = TFIDFVectorStore(store_path)
    store.add_sections(all_sections, rebuild_index=True)
    store.stats()

    print(f"\n✓ Manual database built successfully!")
    print(f"  {store.get_section_count()} sections indexed")
    print(f"  Database: {store_path}/manual_store.db")


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="TxDOT Bridge Inspection AI — PDF Analysis with Manual Guardrails"
    )
    sub = parser.add_subparsers(dest="cmd")

    # Analyze command
    pa = sub.add_parser("analyze", help="Analyze a PDF with manual guardrails")
    pa.add_argument("--input",      required=True,  help="Input inspection PDF")
    pa.add_argument("--output",     required=True,  help="Output annotated PDF")
    pa.add_argument("--task",       default="issues",
                    choices=["issues","summary","ratings","missing","recs","analyze"])
    pa.add_argument("--store-path", default="./vector_store")
    pa.add_argument("--server",     default="http://localhost:1234")
    pa.add_argument("--model",      default="txdot-llm:2")
    pa.add_argument("--max-pages",  type=int, default=8)

    # Build database command
    pb = sub.add_parser("build-db", help="Parse manuals and build vector database")
    pb.add_argument("--manual-dir", default="./manuals/raw")
    pb.add_argument("--store-path", default="./vector_store")

    # Test RAG command
    pt = sub.add_parser("test-rag", help="Test the RAG retrieval system")
    pt.add_argument("--query",      required=True)
    pt.add_argument("--store-path", default="./vector_store")
    pt.add_argument("--element",    default="")

    # Stats command
    ps = sub.add_parser("stats", help="Show database statistics")
    ps.add_argument("--store-path", default="./vector_store")

    args = parser.parse_args()

    if args.cmd == "analyze":
        analyze_pdf(
            input_pdf=args.input,
            output_pdf=args.output,
            task=args.task,
            store_path=args.store_path,
            lm_server=args.server,
            lm_model=args.model,
            max_pages=args.max_pages
        )

    elif args.cmd == "build-db":
        build_database(args.manual_dir, args.store_path)

    elif args.cmd == "test-rag":
        from rag_engine import RAGEngine
        engine = RAGEngine(args.store_path)
        ctx = engine.retrieve(args.query, element=args.element)
        print(f"\nQuery: '{args.query}'")
        print(f"Retrieved {len(ctx.sections)} sections\n")
        for i, s in enumerate(ctx.sections, 1):
            print(f"[{i}] {s.citation} (score={s.score:.3f})")
            print(f"     Elements: {s.element_tags}")
            print(f"     Preview: {s.content[:300]}\n")
        if ctx.guardrails:
            print("Guardrails:")
            for g in ctx.guardrails:
                print(f"  • {g}")

    elif args.cmd == "stats":
        from vector_store import TFIDFVectorStore
        store = TFIDFVectorStore(args.store_path)
        store.stats()

    else:
        parser.print_help()
        print("\nQuick start:")
        print("  1. Add manuals: copy PDFs to ./manuals/raw/")
        print("  2. Build DB:    python inspect.py build-db")
        print("  3. Analyze:     python inspect.py analyze --input report.pdf --output out.pdf")


if __name__ == "__main__":
    main()
