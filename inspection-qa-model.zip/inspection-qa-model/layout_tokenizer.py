"""
layout_tokenizer.py — Layout-Aware PDF Tokenizer
Converts parsed PDF structure (text + coordinates + fonts) into a token stream
that the model can learn from. Encodes WHAT, WHERE, and HOW for every element.

Token format:
  [PAGE_START p=N w=W h=H]
  [BLOCK type=header x=72 y=680 w=200 h=20 fs=12 bold=1]BRIDGE INSPECTION REPORT
  [TABLE rows=4 cols=6 x=50 y=300]
  [CELL r=0 c=0]Element[/CELL][CELL r=0 c=1]Rating[/CELL]
  [/TABLE]
  [FIELD name=deck_rating type=text]5[/FIELD]
  [PAGE_END]
"""

import os
import json
import math
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

log = logging.getLogger(__name__)

try:
    import sentencepiece as spm
    HAS_SPM = True
except ImportError:
    HAS_SPM = False
    log.warning("SentencePiece not found. Install: pip install sentencepiece --break-system-packages")


# ──────────────────────────────────────────────
# Special tokens
# ──────────────────────────────────────────────

SPECIAL_TOKENS = [
    # Page structure
    "[PAGE_START]", "[PAGE_END]",
    # Block types
    "[BLOCK]", "[/BLOCK]",
    "[HEADER]", "[/HEADER]",
    "[LABEL]", "[/LABEL]",
    "[TEXT]", "[/TEXT]",
    "[NUMERIC]", "[/NUMERIC]",
    # Table structure
    "[TABLE]", "[/TABLE]",
    "[ROW]", "[/ROW]",
    "[CELL]", "[/CELL]",
    "[THEAD]", "[/THEAD]",
    # Form fields
    "[FIELD]", "[/FIELD]",
    "[CHECKED]", "[UNCHECKED]",
    # Layout attributes
    "[BOLD]", "[/BOLD]",
    "[ITALIC]", "[/ITALIC]",
    # Position zones (divides page into 10x10 grid)
    *[f"[X{i}]" for i in range(10)],
    *[f"[Y{i}]" for i in range(10)],
    # Font size buckets
    "[FS_SMALL]", "[FS_NORMAL]", "[FS_LARGE]", "[FS_TITLE]",
    # Document structure
    "[DOC_START]", "[DOC_END]",
    "[SEP]",  # separator between elements
    # Task tokens
    "[ANALYZE]", "[SUMMARIZE]", "[FIND_ISSUES]", "[CHECK_RATINGS]",
    "[FIND_MISSING]", "[RECOMMEND]",
    # Special
# Note: [PAD], [UNK], [BOS], [EOS] are registered via dedicated control-symbol
# parameters elsewhere (pad_piece, unk_piece, bos_piece, eos_piece) and must
# NOT be duplicated in user_defined_symbols.
]


# ──────────────────────────────────────────────
# Layout encoding helpers
# ──────────────────────────────────────────────

def quantize_position(value: float, page_size: float, bins: int = 10) -> int:
    """Convert a coordinate to a discrete zone (0-9)."""
    if page_size <= 0:
        return 0
    return min(int(value / page_size * bins), bins - 1)

def quantize_fontsize(size: float) -> str:
    """Convert font size to a discrete token."""
    if size < 9:   return "[FS_SMALL]"
    if size < 12:  return "[FS_NORMAL]"
    if size < 16:  return "[FS_LARGE]"
    return "[FS_TITLE]"

def normalize_coord(value: float, page_size: float) -> int:
    """Normalize coordinate to 0-999 integer."""
    if page_size <= 0:
        return 0
    return min(int(value / page_size * 1000), 999)


# ──────────────────────────────────────────────
# Document → Token Stream
# ──────────────────────────────────────────────

class PDFLayoutTokenizer:
    """
    Converts a ParsedDocument JSON into a structured token stream.
    The stream encodes content, position, and style for every element.
    """

    def __init__(self, coord_precision: int = 10,
                 max_text_per_block: int = 256,
                 include_coords: bool = True,
                 include_style: bool = True):
        self.coord_precision = coord_precision
        self.max_text_per_block = max_text_per_block
        self.include_coords = include_coords
        self.include_style = include_style

    def _pos_tokens(self, x0, y0, x1, y1, page_w, page_h) -> str:
        """Generate position zone tokens."""
        if not self.include_coords:
            return ""
        xz = quantize_position(x0, page_w, self.coord_precision)
        yz = quantize_position(y0, page_h, self.coord_precision)
        return f"[X{xz}][Y{yz}]"

    def _style_tokens(self, bold: bool, italic: bool, size: float) -> str:
        """Generate style tokens."""
        if not self.include_style:
            return ""
        tokens = quantize_fontsize(size)
        if bold:   tokens += "[BOLD]"
        if italic: tokens += "[ITALIC]"
        return tokens

    def encode_block(self, block: dict, page_w: float, page_h: float) -> str:
        """Encode a single text block."""
        text = block.get("text", "").strip()
        if not text:
            return ""

        text = text[:self.max_text_per_block]
        btype = block.get("block_type", "text")
        bold = block.get("bold", False)
        italic = block.get("italic", False)
        size = block.get("size", 10.0)
        x0 = block.get("x0", 0)
        y0 = block.get("y0", 0)
        x1 = block.get("x1", 0)
        y1 = block.get("y1", 0)

        pos = self._pos_tokens(x0, y0, x1, y1, page_w, page_h)
        style = self._style_tokens(bold, italic, size)

        if btype == "header":
            return f"{pos}{style}[HEADER]{text}[/HEADER]"
        elif btype == "label":
            return f"{pos}{style}[LABEL]{text}[/LABEL]"
        elif btype == "numeric_field":
            return f"{pos}{style}[NUMERIC]{text}[/NUMERIC]"
        else:
            return f"{pos}{style}[TEXT]{text}[/TEXT]"

    def encode_table(self, table: dict, page_w: float, page_h: float) -> str:
        """Encode a table with all its cells."""
        x0 = table.get("x0", 0)
        y0 = table.get("y0", 0)
        x1 = table.get("x1", 0)
        y1 = table.get("y1", 0)
        n_rows = table.get("n_rows", 0)
        n_cols = table.get("n_cols", 0)
        cells = table.get("cells", [])

        pos = self._pos_tokens(x0, y0, x1, y1, page_w, page_h)
        result = f"{pos}[TABLE rows={n_rows} cols={n_cols}]"

        # Group cells by row
        rows: Dict[int, List[dict]] = {}
        for cell in cells:
            r = cell.get("row", 0)
            rows.setdefault(r, []).append(cell)

        for r_idx in sorted(rows.keys()):
            row_cells = sorted(rows[r_idx], key=lambda c: c.get("col", 0))
            result += "[ROW]"
            for cell in row_cells:
                cell_text = str(cell.get("text", "")).strip()[:128]
                result += f"[CELL]{cell_text}[/CELL]"
            result += "[/ROW]"

        result += "[/TABLE]"
        return result

    def encode_form_field(self, field: dict, page_w: float, page_h: float) -> str:
        """Encode a PDF form field."""
        name  = field.get("field_name", "").strip()
        value = field.get("field_value", "").strip()
        ftype = field.get("field_type", "text")
        x0 = field.get("x0", 0)
        y0 = field.get("y0", 0)
        x1 = field.get("x1", 0)
        y1 = field.get("y1", 0)

        pos = self._pos_tokens(x0, y0, x1, y1, page_w, page_h)

        if ftype == "checkbox":
            checked = "[CHECKED]" if value.lower() in ("checked", "yes", "true", "1") else "[UNCHECKED]"
            return f"{pos}[FIELD name={name} type=checkbox]{checked}[/FIELD]"
        else:
            return f"{pos}[FIELD name={name} type={ftype}]{value[:128]}[/FIELD]"

    def encode_page(self, page: dict) -> str:
        """Encode a full page into token stream."""
        page_num = page.get("page_num", 0)
        width    = page.get("width", 612)
        height   = page.get("height", 792)
        blocks   = page.get("blocks", [])
        tables   = page.get("tables", [])
        fields   = page.get("form_fields", [])

        result = f"[PAGE_START p={page_num} w={int(width)} h={int(height)}]"

        # Merge all elements and sort by reading order (y then x)
        elements = []
        for b in blocks:
            elements.append(("block", b.get("y0", 0), b.get("x0", 0), b))
        for t in tables:
            elements.append(("table", t.get("y0", 0), t.get("x0", 0), t))
        for f in fields:
            elements.append(("field", f.get("y0", 0), f.get("x0", 0), f))

        elements.sort(key=lambda e: (round(e[1] / 15) * 15, e[2]))

        for etype, _, _, elem in elements:
            if etype == "block":
                encoded = self.encode_block(elem, width, height)
            elif etype == "table":
                encoded = self.encode_table(elem, width, height)
            else:
                encoded = self.encode_form_field(elem, width, height)
            if encoded:
                result += encoded + "[SEP]"

        result += "[PAGE_END]"
        return result

    def encode_document(self, parsed_doc: dict, max_pages: int = 0) -> str:
        """Encode a full document."""
        fname = parsed_doc.get("filename", "")
        pages = parsed_doc.get("pages", [])
        if max_pages:
            pages = pages[:max_pages]

        result = f"[DOC_START file={fname}]"
        for page in pages:
            result += self.encode_page(page)
        result += "[DOC_END]"
        return result

    def encode_instruction(self, task: str, doc_tokens: str, response: str = "") -> str:
        """
        Format a training example as:
        [TASK_TOKEN][DOC_TOKENS][SEP][RESPONSE]
        """
        task_map = {
            "issues":   "[FIND_ISSUES]",
            "summary":  "[SUMMARIZE]",
            "ratings":  "[CHECK_RATINGS]",
            "missing":  "[FIND_MISSING]",
            "recs":     "[RECOMMEND]",
            "analyze":  "[ANALYZE]",
        }
        task_token = task_map.get(task, "[ANALYZE]")
        if response:
            return f"{task_token}{doc_tokens}[SEP]{response}[EOS]"
        else:
            return f"{task_token}{doc_tokens}[SEP]"


# ──────────────────────────────────────────────
# Corpus builder
# ──────────────────────────────────────────────

def build_pretrain_corpus(
    parsed_dir: str,
    output_file: str,
    max_pages_per_doc: int = 10,
    coord_precision: int = 10
):
    """
    Build a pretraining corpus from all parsed PDF JSON files.
    Each document becomes a sequence of layout tokens for unsupervised pretraining.
    """
    parsed_dir = Path(parsed_dir)
    jsons = sorted(parsed_dir.rglob("*.json"))
    log.info(f"Building corpus from {len(jsons)} parsed documents")

    tokenizer = PDFLayoutTokenizer(coord_precision=coord_precision)
    total_chars = 0

    with open(output_file, "w", encoding="utf-8") as out:
        for jpath in jsons:
            try:
                with open(jpath, "r", encoding="utf-8") as f:
                    doc = json.load(f)
                encoded = tokenizer.encode_document(doc, max_pages=max_pages_per_doc)
                out.write(encoded + "\n")
                total_chars += len(encoded)
            except Exception as e:
                log.warning(f"Skipping {jpath.name}: {e}")

    log.info(f"Corpus written to {output_file} — {total_chars:,} chars from {len(jsons)} documents")
    return total_chars


def build_sft_corpus(
    labeled_dir: str,
    parsed_dir: str,
    output_file: str,
    coord_precision: int = 10
):
    """
    Build a supervised fine-tuning corpus from labeled examples.
    Each label file: {"pdf": "filename.json", "task": "issues", "response": "..."}
    """
    labeled_dir = Path(labeled_dir)
    parsed_dir  = Path(parsed_dir)
    labels = sorted(labeled_dir.glob("*.json"))
    log.info(f"Building SFT corpus from {len(labels)} labeled examples")

    tokenizer = PDFLayoutTokenizer(coord_precision=coord_precision)
    examples = []

    for lpath in labels:
        try:
            with open(lpath, "r", encoding="utf-8") as f:
                label = json.load(f)

            pdf_json = parsed_dir / label["pdf"]
            if not pdf_json.exists():
                log.warning(f"Parsed PDF not found: {label['pdf']}")
                continue

            with open(pdf_json, "r", encoding="utf-8") as f:
                doc = json.load(f)

            # Use only pages specified, or first 5 pages
            pages = label.get("pages", None)
            if pages:
                doc["pages"] = [p for p in doc["pages"] if p["page_num"] in pages]
            else:
                doc["pages"] = doc["pages"][:5]

            doc_tokens = tokenizer.encode_document(doc)
            task = label.get("task", "analyze")
            response = label.get("response", "")
            example = tokenizer.encode_instruction(task, doc_tokens, response)
            examples.append(example)

        except Exception as e:
            log.warning(f"Skipping {lpath.name}: {e}")

    with open(output_file, "w", encoding="utf-8") as out:
        for ex in examples:
            out.write(ex + "\n")

    log.info(f"SFT corpus written: {len(examples)} examples → {output_file}")
    return len(examples)


# ──────────────────────────────────────────────
# Tokenizer training
# ──────────────────────────────────────────────

def train_layout_tokenizer(
    corpus_file: str,
    model_prefix: str = "tokenizer/layout_bpe",
    vocab_size: int = 16000
):
    """Train a BPE tokenizer on the layout token corpus."""
    if not HAS_SPM:
        raise ImportError("Install sentencepiece: pip install sentencepiece --break-system-packages")

    os.makedirs(os.path.dirname(model_prefix) or ".", exist_ok=True)
    log.info(f"Training layout tokenizer — vocab_size={vocab_size}")

    spm.SentencePieceTrainer.train(
        input=corpus_file,
        model_prefix=model_prefix,
        vocab_size=vocab_size,
        model_type="bpe",
        character_coverage=0.9999,
        pad_id=0, unk_id=1, bos_id=2, eos_id=3,
        pad_piece="[PAD]", unk_piece="[UNK]",
        bos_piece="[BOS]", eos_piece="[EOS]",
        user_defined_symbols=SPECIAL_TOKENS,
        normalization_rule_name="identity",
        remove_extra_whitespaces=False,
        input_sentence_size=2_000_000,
        shuffle_input_sentence=True,
        num_threads=max(1, os.cpu_count() - 1),
    )
    log.info(f"Layout tokenizer saved: {model_prefix}.model")


class LayoutBPETokenizer:
    """Wrapper around trained SentencePiece layout tokenizer."""
    def __init__(self, model_path: str):
        if not HAS_SPM:
            raise ImportError("sentencepiece required")
        self.sp = spm.SentencePieceProcessor()
        self.sp.load(model_path)
        self.vocab_size = self.sp.get_piece_size()
        self.pad_id = self.sp.pad_id()
        self.bos_id = self.sp.bos_id()
        self.eos_id = self.sp.eos_id()

    def encode(self, text: str) -> List[int]:
        return self.sp.encode(text, out_type=int)

    def decode(self, ids: List[int]) -> str:
        return self.sp.decode(ids)

    def encode_doc_for_inference(self, parsed_doc: dict, task: str,
                                  max_pages: int = 5) -> List[int]:
        """Tokenize a document for inference (no response)."""
        lt = PDFLayoutTokenizer()
        doc_tokens = lt.encode_document(parsed_doc, max_pages=max_pages)
        prompt = lt.encode_instruction(task, doc_tokens, response="")
        return self.encode(prompt)


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Layout tokenizer operations")
    sub = p.add_subparsers(dest="cmd")

    pb = sub.add_parser("build-pretrain", help="Build pretraining corpus")
    pb.add_argument("--parsed-dir",  default="./data/processed")
    pb.add_argument("--output",      default="./data/pretrain_corpus.txt")
    pb.add_argument("--max-pages",   type=int, default=10)

    ps = sub.add_parser("build-sft", help="Build SFT corpus from labels")
    ps.add_argument("--labeled-dir", default="./data/labeled")
    ps.add_argument("--parsed-dir",  default="./data/processed")
    ps.add_argument("--output",      default="./data/sft_corpus.txt")

    pt = sub.add_parser("train-tokenizer", help="Train BPE tokenizer on corpus")
    pt.add_argument("--corpus",      default="./data/pretrain_corpus.txt")
    pt.add_argument("--prefix",      default="./tokenizer/layout_bpe")
    pt.add_argument("--vocab-size",  type=int, default=16000)

    args = p.parse_args()

    if args.cmd == "build-pretrain":
        build_pretrain_corpus(args.parsed_dir, args.output, args.max_pages)
    elif args.cmd == "build-sft":
        build_sft_corpus(args.labeled_dir, args.parsed_dir, args.output)
    elif args.cmd == "train-tokenizer":
        train_layout_tokenizer(args.corpus, args.prefix, args.vocab_size)
    else:
        p.print_help()
